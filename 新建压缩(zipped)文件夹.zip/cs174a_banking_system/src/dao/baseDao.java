package dao;

import java.sql.Connection;

import utility.dbUtil;

public class baseDao {
	public Connection con = new dbUtil().getCon();
}
