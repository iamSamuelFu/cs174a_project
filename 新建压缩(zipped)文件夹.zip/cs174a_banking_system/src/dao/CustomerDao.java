package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import utility.dbUtil;
import model.Account;
import model.Customer;

public class CustomerDao extends baseDao {
	
	public void insertCustomer(Customer customer){
		String sql = "INSERT INTO Customers(username, TIN, name, address, PIN)"+
				 	 "VALUES(?, ?, ?, ?, ?)";
		try {
			// pass sql query 
			Connection con = new dbUtil().getCon();
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setString(1, customer.getUsername());
			prst.setString(2, customer.getTIN());
			prst.setString(3, customer.getName());
			prst.setString(4, customer.getAddress());
			prst.setString(5, customer.getPIN());
			prst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ArrayList<Customer> getAllCustomers(){
		String sql = "select * from Customers";
		ArrayList<Customer> customers = new ArrayList<Customer>();
		try {
			// pass sql query 
			Connection con = new dbUtil().getCon();
			PreparedStatement prst = con.prepareStatement(sql);
			ResultSet executeQuery = prst.executeQuery();
			while(executeQuery.next()){
				Customer cst = new Customer();
				cst.setAddress(executeQuery.getString("address"));
				cst.setName(executeQuery.getString("name"));
				cst.setPIN(executeQuery.getString("PIN"));
				cst.setTIN(executeQuery.getString("TIN"));
				cst.setUsername(executeQuery.getString("username"));
				customers.add(cst);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customers;
	}
	
	
	
	public ArrayList<Account> getAllClosedAccounts(){
		String sql = "select * from Accounts where active = 0";
		ArrayList<Account> accounts = new ArrayList<Account> ();
		try {
			// pass sql query 
			Connection con = new dbUtil().getCon();
			PreparedStatement prst = con.prepareStatement(sql);
			ResultSet executeQuery = prst.executeQuery();
			while(executeQuery.next()){
				Account acctRst = new Account();
				acctRst.setAcctID(executeQuery.getInt("acctID"));
				acctRst.setBalance(executeQuery.getDouble("balance"));
				acctRst.setBranch(executeQuery.getString("branch"));
				acctRst.setPrimaryTIN(executeQuery.getString("primaryTIN"));
				acctRst.setType(executeQuery.getString("type"));
				acctRst.setSubType(executeQuery.getString("subType"));
				acctRst.setActive(executeQuery.getBoolean("active"));
				acctRst.setInterestRate(executeQuery.getDouble("interestRate"));
				acctRst.setLinkID(executeQuery.getInt("linkID"));
				accounts.add(acctRst);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return accounts;
	}
	
	/**
	 * �û���¼
	 */
	
	public Customer verifyPIN(Customer customer){
		String sql = "select * from Customers where username=?";
		Customer customerRst = null;
		try {
			// pass sql query 
			Connection con = new dbUtil().getCon();
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setString(1, customer.getUsername());
			ResultSet executeQuery = prst.executeQuery();
			if(executeQuery.next()){
				String enteredPIN = customer.getPIN();
				String correctPIN = executeQuery.getString("PIN");
				if(enteredPIN.equals(correctPIN)){
					customerRst = new Customer();
					customerRst.setUsername(executeQuery.getString("username"));
					customerRst.setTIN(executeQuery.getString("TIN"));
					customerRst.setName(executeQuery.getString("name"));
					customerRst.setAddress(executeQuery.getString("address"));
					customerRst.setPIN(executeQuery.getString("PIN"));
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return customerRst;
	}
	
	public ArrayList<Account> getAccounts(Customer customer){
		String sql = "select * from Accounts where active = 1 AND acctID in (select acctID from Ownership where TIN=?)";
		ArrayList<Account> accounts = new ArrayList<Account> ();
		try {
			// pass sql query 
			Connection con = new dbUtil().getCon();
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setString(1, customer.getTIN());
			ResultSet executeQuery = prst.executeQuery();
			while(executeQuery.next()){
				Account acctRst = new Account();
				acctRst.setAcctID(executeQuery.getInt("acctID"));
				acctRst.setBalance(executeQuery.getDouble("balance"));
				acctRst.setBranch(executeQuery.getString("branch"));
				acctRst.setPrimaryTIN(executeQuery.getString("primaryTIN"));
				acctRst.setType(executeQuery.getString("type"));
				acctRst.setSubType(executeQuery.getString("subType"));
				acctRst.setActive(executeQuery.getBoolean("active"));
				acctRst.setInterestRate(executeQuery.getDouble("interestRate"));
				acctRst.setLinkID(executeQuery.getInt("linkID"));
				accounts.add(acctRst);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return accounts;

	}
	
	public ArrayList<Account> getAllAccounts(){
		String sql = "select * from Accounts where active = 1";
		ArrayList<Account> accounts = new ArrayList<Account> ();
		try {
			// pass sql query 
			PreparedStatement prst = con.prepareStatement(sql);
			ResultSet executeQuery = prst.executeQuery();
			while(executeQuery.next()){
				Account acctRst = new Account();
				acctRst.setAcctID(executeQuery.getInt("acctID"));
				acctRst.setBalance(executeQuery.getDouble("balance"));
				acctRst.setBranch(executeQuery.getString("branch"));
				acctRst.setPrimaryTIN(executeQuery.getString("primaryTIN"));
				acctRst.setType(executeQuery.getString("type"));
				acctRst.setSubType(executeQuery.getString("subType"));
				acctRst.setActive(executeQuery.getBoolean("active"));
				acctRst.setInterestRate(executeQuery.getDouble("interestRate"));
				acctRst.setLinkID(executeQuery.getInt("linkID"));
				accounts.add(acctRst);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return accounts;
	}
}
