package dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import model.Transaction;

public class TransactionDao extends baseDao {
	public void insertTransaction(Transaction transaction){
		String sql = "INSERT INTO Transactions(fromAcctID, toAcctID, transacType, dates, amount, checkNum)"+
					 "VALUES(?, ?, ?, ?, ?, ?)";
		int rst = 0;
		try {
			// pass sql query 
			PreparedStatement prst = con.prepareStatement(sql);
			if(transaction.getFromAcctID() == -1){
				prst.setNull(1, java.sql.Types.INTEGER);
			}else{
				prst.setInt(1, transaction.getFromAcctID());
			}
			if(transaction.getToAcctID() == -1){
				prst.setNull(2, java.sql.Types.INTEGER);
			}else{
				prst.setInt(2, transaction.getToAcctID());
			}
			prst.setString(3, transaction.getTransacType());
			prst.setDate(4, transaction.getDates());
			prst.setDouble(5, transaction.getAmount());
			if(transaction.getCheckNum() == -1){
				prst.setNull(6, java.sql.Types.INTEGER);
			}else{
				prst.setInt(6, transaction.getCheckNum());
			}
			prst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
