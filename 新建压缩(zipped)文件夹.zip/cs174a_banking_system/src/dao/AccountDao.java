package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;

import javax.swing.JOptionPane;

import utility.dateUtil;
import utility.dbUtil;
import model.Account;
import model.Customer;
import model.Transaction;

public class AccountDao extends baseDao {
	public boolean closeAccount(Account acct){
		String sql = "update Accounts set active = 0 where acctID = ?";
		int rst = 0;
		boolean bool = false;
		try {
			// pass sql query 
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setInt(1, acct.getAcctID());
			rst = prst.executeUpdate();
			if(rst > 0){
				bool = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bool;
	}
	
	public boolean isOwned(int AcctID, String TIN){
		String sql = "Select * from Ownership where acctID = ? AND TIN = ?";
		boolean bool = false;
		try{
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setInt(1, AcctID);
			prst.setString(2, TIN);
			ResultSet rst = prst.executeQuery();
			if(rst.next()){
				bool = true;
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bool;
	}
	
	public void insertOwnership(int AcctID, String TIN){
		String sql = "INSERT INTO Ownership(acctID, TIN)"+
				 	 "VALUES(?, ?)";
		try {
			// pass sql query 
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setInt(1, AcctID);
			prst.setString(2, TIN);
			prst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void insertAccount(Account account){
		String sql = "INSERT INTO Accounts(acctID, balance, branch, primaryTIN, type, subType, active, interestRate, linkID, closedDates)"+
					 "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		int rst = 0;
		try {
			// pass sql query 
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setInt(1, account.getAcctID());
			prst.setDouble(2, account.getBalance());
			prst.setString(3, account.getBranch());
			prst.setString(4, account.getPrimaryTIN());
			prst.setString(5, account.getType());
			prst.setString(6, account.getSubType());
			prst.setInt(7, Boolean.compare(account.isActive(), false));
			prst.setDouble(8, account.getInterestRate());
			if(account.getLinkID() == -1){
				prst.setNull(9, java.sql.Types.INTEGER);
			}else{
				prst.setInt(9, account.getLinkID());
			}
			prst.setDate(10, account.getClosedDates());
			prst.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public boolean deleteAcctCustomer() {
		// TODO Auto-generated method stub
		String sql1 = "delete from Accounts where active = 0";
		String sql2 = "delete from Customers where TIN NOT IN (select TIN from Ownership)";
		boolean bool = false;
		try {
			// pass sql query 
			PreparedStatement prst1 = con.prepareStatement(sql1);
			prst1.executeUpdate();
			PreparedStatement prst2 = con.prepareStatement(sql2);
			prst2.executeUpdate();
			bool = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bool;
	}
	
	public boolean deleteTransaction() {
		// TODO Auto-generated method stub
		String sql = "delete from Transactions where dates BETWEEN ? and ?";
		int rst = 0;
		boolean bool = false;
		
		dateUtil du = new dateUtil();
		Calendar cal = Calendar.getInstance();
		cal.setTime(du.getSysDate());
		cal.add(Calendar.MONTH, -1);
		cal.set(Calendar.DATE, 1);
		Date firstDateOfPreviousMonth = new Date(cal.getTime().getTime());
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE)); // changed calendar to cal
		Date lastDateOfPreviousMonth = new Date(cal.getTime().getTime());
		
		try {
			// pass sql query 
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setDate(1, firstDateOfPreviousMonth);
			prst.setDate(2, lastDateOfPreviousMonth);
			rst = prst.executeUpdate();
			
			if(rst > 0){
				System.out.print(rst);
				bool = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		return bool;
	}
	
	public boolean checkTransaction(Account acct, Double amount){
		String sql = "update Accounts set balance = ? where acctID = ?";
		int rst = 0;
		boolean bool = false;
		try {
			// pass sql query 
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setDouble(1, acct.getBalance() - amount);
			prst.setInt(2, acct.getAcctID());
			rst = prst.executeUpdate();
			if(rst > 0){
				bool = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bool;
	}
	public boolean payFriend(Account from, Account to, Double amount){
		String sql1 = "update Accounts set balance = ? where acctID = ?";
		String sql2 = "update Accounts set balance = ? where acctID = ?";
		int rst1 = 0;
		int rst2 = 0;
		boolean bool = false;
		try {
			// pass sql query 
			PreparedStatement prst1 = con.prepareStatement(sql1);
			PreparedStatement prst2 = con.prepareStatement(sql2);
			prst1.setDouble(1, from.getBalance() - amount);
			prst1.setInt(2, from.getAcctID());
			prst2.setDouble(1, to.getBalance() + amount);
			prst2.setInt(2, to.getAcctID());
			rst1 = prst1.executeUpdate();
			rst2 = prst2.executeUpdate();
			if(rst1 > 0 && rst2 > 0){
				bool = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bool;
	}
	
	public double collect(Account pocketAcct, Double amount){
		String sql = "select * from Accounts where acctID = ? AND ROWNUM <= 1";
		double balance = -1;
		try{
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setInt(1, pocketAcct.getLinkID());
			ResultSet rst = prst.executeQuery();
			if(rst.next()){
				balance = rst.getDouble("balance");
			}else{
				return balance;
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// insufficient fund
		if(pocketAcct.getBalance() < amount*1.03){
			return -2;
		}
		
		if((pocketAcct.getBalance()- amount*1.03) <= 0.01){
			String sql3 = "update Accounts set active = 0 where acctID = ?";
			try{
				PreparedStatement prst = con.prepareStatement(sql3);
				prst.setInt(1, pocketAcct.getAcctID());
				prst.executeQuery();
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
				
		String sql1 = "update Accounts set balance = ? where acctID = ?";
		String sql2 = "update Accounts set balance = ? where acctID = ?";
		
		int rst1 = 0;
		int rst2 = 0;
		try {
			// pass sql query 
			PreparedStatement prst1 = con.prepareStatement(sql1);
			prst1.setDouble(1, pocketAcct.getBalance() - amount*1.03);
			prst1.setInt(2, pocketAcct.getAcctID());
			rst1 = prst1.executeUpdate();
			if(rst1 == 0){
				return -1;
			}
			
			PreparedStatement prst2 = con.prepareStatement(sql2);
			prst2.setDouble(1, balance + amount);
			prst2.setInt(2, pocketAcct.getLinkID());
			rst2 = prst2.executeUpdate();
			if(rst2 == 0){
				return -1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try{
		         if(con!=null)
		            con.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }
		}
		return balance;
	}
	
	public boolean purchase(Account acct, Double amount){
		String sql = "update Accounts set balance = ? where acctID = ?";
		int rst = 0;
		boolean bool = false;
		try {
			// pass sql query 
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setDouble(1, acct.getBalance() - amount);
			prst.setInt(2, acct.getAcctID());
			rst = prst.executeUpdate();
			if(rst > 0){
				bool = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bool;
	}
	
	
	public double topUp(Account pocketAcct, Double amount){
		String sql = "select * from Accounts where acctID = ? AND ROWNUM <= 1";
		double balance = -1;
		try{
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setInt(1, pocketAcct.getLinkID());
			ResultSet rst = prst.executeQuery();
			if(rst.next()){
				balance = rst.getDouble("balance");
			}else{
				return balance;
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		double amountToPkt = amount;
		if(!alreadyAddedFee(pocketAcct)){
			amountToPkt = amountToPkt - 5;
		}
		// insufficient fund
		if(balance < amount){
			return -2;
		}
		
		if((balance-amount) <= 0.01){
			String sql3 = "update Accounts set active = 0 where acctID = ?";
			try{
				PreparedStatement prst = con.prepareStatement(sql3);
				prst.setInt(1, pocketAcct.getLinkID());
				prst.executeQuery();
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
				
		String sql1 = "update Accounts set balance = ? where acctID = ?";
		String sql2 = "update Accounts set balance = ? where acctID = ?";
		
		int rst1 = 0;
		int rst2 = 0;
		try {
			// pass sql query 
			PreparedStatement prst1 = con.prepareStatement(sql1);
			prst1.setDouble(1, pocketAcct.getBalance() + amountToPkt);
			prst1.setInt(2, pocketAcct.getAcctID());
			rst1 = prst1.executeUpdate();
			if(rst1 == 0){
				return -1;
			}
			
			PreparedStatement prst2 = con.prepareStatement(sql2);
			prst2.setDouble(1, balance - amount);
			prst2.setInt(2, pocketAcct.getLinkID());
			rst2 = prst2.executeUpdate();
			if(rst2 == 0){
				return -1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try{
		         if(con!=null)
		            con.close();
		      }catch(SQLException se){
		         se.printStackTrace();
		      }
		}
		return balance;
	}
	
	public boolean setPIN(Customer customer, String oldPIN, String newPIN){
		String sql = "update Customers set PIN = ? where username = ?";
		int rst = 0;
		boolean bool = false;
		try {
			// pass sql query 
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setString(1, newPIN);
			prst.setString(2, customer.getUsername());
			rst = prst.executeUpdate();
			if(rst > 0){
				bool = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bool;
		
	}
	public boolean deposit(Account acct, Double amount){
		String sql = "update Accounts set balance = ? where acctID = ?";
		int rst = 0;
		boolean bool = false;
		try {
			// pass sql query 
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setDouble(1, acct.getBalance() + amount);
			prst.setInt(2, acct.getAcctID());
			rst = prst.executeUpdate();
			if(rst > 0){
				bool = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bool;
	}
	
	public boolean withdrawl(Account acct, Double amount){
		String sql = "update Accounts set balance = ? where acctID = ?";
		int rst = 0;
		boolean bool = false;
		try {
			// pass sql query 
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setDouble(1, acct.getBalance() - amount);
			prst.setInt(2, acct.getAcctID());
			rst = prst.executeUpdate();
			if(rst > 0){
				bool = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bool;
	}
	
	public boolean transfer(Account from, Account to, Double amount){
		String sql1 = "update Accounts set balance = ? where acctID = ?";
		String sql2 = "update Accounts set balance = ? where acctID = ?";
		int rst1 = 0;
		int rst2 = 0;
		boolean bool = false;
		try {
			// pass sql query 
			PreparedStatement prst1 = con.prepareStatement(sql1);
			PreparedStatement prst2 = con.prepareStatement(sql2);
			prst1.setDouble(1, from.getBalance() - amount);
			prst1.setInt(2, from.getAcctID());
			prst2.setDouble(1, to.getBalance() + amount);
			prst2.setInt(2, to.getAcctID());
			rst1 = prst1.executeUpdate();
			rst2 = prst2.executeUpdate();
			if(rst1 > 0 && rst2 > 0){
				bool = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bool;
	}
	
	public boolean wire(Account from, Account to, Double amount){
		String sql1 = "update Accounts set balance = ? where acctID = ?";
		String sql2 = "update Accounts set balance = ? where acctID = ?";
		int rst1 = 0;
		int rst2 = 0;
		boolean bool = false;
		try {
			// pass sql query 
			PreparedStatement prst1 = con.prepareStatement(sql1);
			PreparedStatement prst2 = con.prepareStatement(sql2);
			prst1.setDouble(1, from.getBalance() - amount*1.02);
			prst1.setInt(2, from.getAcctID());
			prst2.setDouble(1, to.getBalance() + amount);
			prst2.setInt(2, to.getAcctID());
			rst1 = prst1.executeUpdate();
			rst2 = prst2.executeUpdate();
			if(rst1 > 0 && rst2 > 0){
				bool = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bool;
	}
	public boolean setIR(String acctType, Double newIR) {
		// TODO Auto-generated method stub
		String sql = "";
		int rst = 0;
		boolean bool = false;
		if(acctType.contains("Student")){
			sql = "update Accounts set interestRate = ? where subType = ?";
		}
		if(acctType.contains("Interest")){
			sql = "update Accounts set interestRate = ? where subType = ?";
		}
		if("Savings".equals(acctType)){
			sql = "update Accounts set interestRate = ? where type = ?";
		}
		if("Pocket".equals(acctType)){
			sql = "update Accounts set interestRate = ? where type = ?";
		}
		try {
			// pass sql query 
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setDouble(1, newIR);
			if(acctType.contains("Student")){
				prst.setString(2, "Student");
			}
			if(acctType.contains("Interest")){
				prst.setString(2, "Interest");
			}
			if("Savings".equals(acctType)){
				prst.setString(2, "Saving");
			}
			if("Pocket".equals(acctType)){
				prst.setString(2, "Pocket");
			}
			rst = prst.executeUpdate();
			if(rst > 0){
				bool = true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return bool;
	}

	public boolean addInterest() {
		boolean bool = true;
		String sql0 = "Select flag from vals";
		boolean has_added = false;
		
		try {
			PreparedStatement prst1 = con.prepareStatement(sql0);
			ResultSet rst1 = prst1.executeQuery();
			if(rst1.next()){
				if((rst1.getInt("flag"))==1) {
					has_added = true;
					bool = false;
				}
			}
			
		}catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			bool = false;
		}
		
		if(!has_added) {
			
			String sql1 = "Select acctID from Accounts where active = 1";
			ArrayList<Integer> activeAccount = new ArrayList<Integer>();
			int rst = 0;
			
			try {
				PreparedStatement prst1 = con.prepareStatement(sql1);
				ResultSet rst1 = prst1.executeQuery();
				
				while(rst1.next()){
					activeAccount.add(rst1.getInt("acctID"));
				}
			}catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				bool = false;
			}
			
	        for (Integer account: activeAccount) {
	        	
	        	double initBalance = 0;
	        	double currentBalance = 0;
	        	String type;
	        	String subType;
	        	double interestRate = 0;
	        	double sumBalance = 0;
	        	
	        	String sql3 = "Select * from Accounts where acctID = ?";
	
	        	try {
	        		PreparedStatement prst3 = con.prepareStatement(sql3);
	        		prst3.setInt(1, account);
	        		ResultSet rst3 = prst3.executeQuery();
	        		if(rst3.next()){
	        			initBalance = rst3.getDouble("balance");
	        			currentBalance = rst3.getDouble("balance");
	        			type = rst3.getString("type");
	        			subType = rst3.getString("subType");
	        			interestRate = rst3.getDouble("interestRate");
	        		}
	        	}catch (SQLException e) {
	    			// TODO Auto-generated catch block
	    			e.printStackTrace();
	    			bool = false;
	    		}
	    	
	        	ArrayList<Transaction> transactions = new ArrayList<>();
	        	String sql2 = "select * from Transactions where fromAcctID = ? or toAcctID = ? ORDER BY dates";
	        	try {
	        		PreparedStatement prst2 = con.prepareStatement(sql2);
	        		prst2.setInt(1, account);
	        		prst2.setInt(2, account);
	        		ResultSet rst2 = prst2.executeQuery();
	        		
	        		while(rst2.next()){
	        			Transaction onetransaction = new Transaction();
	        			onetransaction.setTransacID(rst2.getInt("transacID"));
	        			onetransaction.setFromAcctID(rst2.getInt("fromAcctID"));
	        			onetransaction.setToAcctID(rst2.getInt("toAcctID"));
	        			onetransaction.setTransacType(rst2.getString("transacType"));
	        			onetransaction.setDates(rst2.getDate("dates"));
	        			onetransaction.setAmount(rst2.getDouble("amount"));
	        			onetransaction.setCheckNum(rst2.getInt("checkNum"));
	        			transactions.add(onetransaction);
	        		
	        		}
	        		}catch (SQLException e) {
	        			// TODO Auto-generated catch block
	        			e.printStackTrace();
	        			bool = false;
	        		}
	        	Collections.reverse(transactions);
	        	
	        	int prev_day = 31;
	        	for(Transaction currentTransaction: transactions) {
	        		double amount = currentTransaction.getAmount();
	        		int current_day = Integer.parseInt(currentTransaction.getDates().toString().substring(8, 10));
	        		int duration = prev_day - current_day;
	        		prev_day = current_day;
	        		sumBalance += duration * currentBalance;
	        		if (currentTransaction.getTransacType().equals("Deposit") ){
	        			if(account == currentTransaction.getToAcctID()){
	        				currentBalance -= amount;
	        			}
	        		}else if( currentTransaction.getTransacType().equals("Top-Up")){
	        			if(account == currentTransaction.getFromAcctID()){
	        				currentBalance += amount;
	        			}else if (account == currentTransaction.getToAcctID()){
	        				currentBalance -= amount;
	        			}
	        		}else if( currentTransaction.getTransacType().equals("Withdrawal")){
	        			if(account == currentTransaction.getFromAcctID()){
	        				currentBalance += amount;
	        			}
	        		}else if( currentTransaction.getTransacType().equals("Purchase")){
	        			if(account == currentTransaction.getFromAcctID()){
	        				currentBalance += amount;
	        			}
	        		}else if( currentTransaction.getTransacType().equals("Transfer")){
	        			if(account == currentTransaction.getFromAcctID()){
	        				currentBalance += amount;
	        			}else if (account == currentTransaction.getToAcctID()){
	        				currentBalance -= amount;
	        			}
	
	        		}else if( currentTransaction.getTransacType().equals("Collect")){
	        			if(account == currentTransaction.getFromAcctID()){
	        				currentBalance += amount;
	        			}else if (account == currentTransaction.getToAcctID()){
	        				currentBalance -= amount;
	        			}
	
	        		}else if( currentTransaction.getTransacType().equals("Pay-Friend")){
	        			if(account == currentTransaction.getFromAcctID()){
	        				currentBalance += amount;
	        			}else if (account == currentTransaction.getToAcctID()){
	        				currentBalance -= amount;
	        			}
	
	        		}else if( currentTransaction.getTransacType().equals("Wire")){
	        			if(account == currentTransaction.getFromAcctID()){
	        				currentBalance += amount;
	        			}else if (account == currentTransaction.getToAcctID()){
	        				currentBalance -= amount;
	        			}
	        		}
	
	        		else if( currentTransaction.getTransacType().equals("Write-Check")){
	        			if(account == currentTransaction.getFromAcctID()){
	        				currentBalance += amount;
	        			}
	
	        		}else if( currentTransaction.getTransacType().equals("Accrue-Interest")){
	        			if (account == currentTransaction.getToAcctID()){
	        				currentBalance -= amount;
	        			}
	
	        		}
	        	}
	        	
	        	sumBalance += prev_day * currentBalance;
	    		double interest = interestRate /12;
	    		double avgBalance = sumBalance / 31;
	    		double newBalance = avgBalance * interest + initBalance;
	    		String sql4 = "update Accounts set balance = ? where acctID = ?";
	    		try {
	    			PreparedStatement prst4 = con.prepareStatement(sql4);
	        		prst4.setDouble(1, newBalance);
	        		prst4.setInt(2, account);
	        		rst = prst4.executeUpdate();
	
	    		}catch (SQLException e) {
	    			// TODO Auto-generated catch block
	    			e.printStackTrace();
	    			bool = false;
	    		}
	    	}
	        
	        String sql5 = "Update vals set flag = 1";
			
			try {
				PreparedStatement prst5 = con.prepareStatement(sql5);
				prst5.executeUpdate();
			}catch(SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				bool = false;
			}
	        
	        try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				bool = false;
			}
		} 
		return bool;
	}
	
	/////////////////////////////////////////////////////////////////////////////////////////////////
	public boolean generateMonthly(Customer customer) {
		// Todo 
		return false;
	}
	
	public ArrayList<Account> getStatementAccounts(Customer customer){
		String sql = "select * from Accounts where primaryTIN = ?";
		ArrayList<Account> accounts = new ArrayList<Account> ();
		try {
			//System.out.print("try1");
			// pass sql query 
			Connection con = new dbUtil().getCon();
			PreparedStatement prst = con.prepareStatement(sql);
			//System.out.print("try2");
			//System.out.print(customer.getTIN());
			prst.setString(1, customer.getTIN());

			ResultSet executeQuery = prst.executeQuery();
			//System.out.print("try3");
			while(executeQuery.next()){
				//System.out.print("try4");
				Account acctRst = new Account();
				acctRst.setAcctID(executeQuery.getInt("acctID"));
				acctRst.setBalance(executeQuery.getDouble("balance"));
				acctRst.setBranch(executeQuery.getString("branch"));
				acctRst.setPrimaryTIN(executeQuery.getString("primaryTIN"));
				acctRst.setType(executeQuery.getString("type"));
				acctRst.setSubType(executeQuery.getString("subType"));
				acctRst.setActive(executeQuery.getBoolean("active"));
				acctRst.setInterestRate(executeQuery.getDouble("interestRate"));
				acctRst.setLinkID(executeQuery.getInt("linkID"));
				accounts.add(acctRst);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return accounts;

	}
	
	public ArrayList<Transaction> transactionForOneAccount(Account account) {
		ArrayList<Transaction> transactions = new ArrayList<Transaction>();
//		String sql1 = "select acctID from Accounts where primaryTIN = ?";
//		ArrayList<Integer> accounts = new ArrayList<Integer>();
//		try {
//    		PreparedStatement prst1 = con.prepareStatement(sql1);
//    		prst1.setString(1, customer.getTIN());
//    		ResultSet rst1 = prst1.executeQuery();
//    		
//    		while(rst1.next()){
//    			accounts.add(rst1.getInt("acctID"));   		
//    		}
//    		}catch (SQLException e) {
//    			// TODO Auto-generated catch block
//    			e.printStackTrace();
//    		}
//
//		for (Integer everyAccount: accounts) {
			String sql2 = "select * from Transactions where fromAcctID = ? or toAcctID = ? ORDER BY dates";
        	try {
        		PreparedStatement prst2 = con.prepareStatement(sql2);
        		prst2.setInt(1, account.getAcctID());
        		prst2.setInt(2, account.getAcctID());
        		ResultSet rst2 = prst2.executeQuery();
        		
        		while(rst2.next()){
        			Transaction onetransaction = new Transaction();
        			onetransaction.setTransacID(rst2.getInt("transacID"));
        			onetransaction.setFromAcctID(rst2.getInt("fromAcctID"));
        			onetransaction.setToAcctID(rst2.getInt("toAcctID"));
        			onetransaction.setTransacType(rst2.getString("transacType"));
        			onetransaction.setDates(rst2.getDate("dates"));
        			onetransaction.setAmount(rst2.getDouble("amount"));
        			onetransaction.setCheckNum(rst2.getInt("checkNum"));
        			transactions.add(onetransaction);
        		
        		}
        		}catch (SQLException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		}
//		}
		
		return transactions;
		
	}
	
	
	
	public double initBalance(Account account) {
		double initBalance = account.getBalance();
    	double finalBalance = account.getBalance();
    	double currentBalance = account.getBalance();
    	int accountID = account.getAcctID();
		ArrayList<Transaction> transactions = new ArrayList<>();
    	String sql2 = "select * from Transactions where fromAcctID = ? or toAcctID = ? ORDER BY dates";
    	try {
    		PreparedStatement prst2 = con.prepareStatement(sql2);
    		prst2.setInt(1, account.getAcctID());
    		prst2.setInt(2, account.getAcctID());
    		ResultSet rst2 = prst2.executeQuery();
    		
    		while(rst2.next()){
    			Transaction onetransaction = new Transaction();
    			onetransaction.setTransacID(rst2.getInt("transacID"));
    			onetransaction.setFromAcctID(rst2.getInt("fromAcctID"));
    			onetransaction.setToAcctID(rst2.getInt("toAcctID"));
    			onetransaction.setTransacType(rst2.getString("transacType"));
    			onetransaction.setDates(rst2.getDate("dates"));
    			onetransaction.setAmount(rst2.getDouble("amount"));
    			onetransaction.setCheckNum(rst2.getInt("checkNum"));
    			transactions.add(onetransaction);
    		
    		}
    		}catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    	
    	Collections.reverse(transactions);
    	
    	int prev_day = 31;
    	for(Transaction currentTransaction: transactions) {
    		double amount = currentTransaction.getAmount();
    		int current_day = Integer.parseInt(currentTransaction.getDates().toString().substring(8, 10));
    		int duration = prev_day - current_day;
    		prev_day = current_day;
    		if (currentTransaction.getTransacType().equals("Deposit") ){
    			if(accountID == currentTransaction.getToAcctID()){
    				currentBalance -= amount;
    			}
    		}else if( currentTransaction.getTransacType().equals("Top-Up")){
    			if(accountID == currentTransaction.getFromAcctID()){
    				currentBalance += amount;
    			}else if (accountID == currentTransaction.getToAcctID()){
    				currentBalance -= amount;
    			}
    		}else if( currentTransaction.getTransacType().equals("Withdrawl")){
    			if(accountID == currentTransaction.getFromAcctID()){
    				currentBalance += amount;
    			}
    		}else if( currentTransaction.getTransacType().equals("Purchase")){
    			if(accountID == currentTransaction.getFromAcctID()){
    				currentBalance += amount;
    			}
    		}else if( currentTransaction.getTransacType().equals("Transfer")){
    			if(accountID == currentTransaction.getFromAcctID()){
    				currentBalance += amount;
    			}else if (accountID == currentTransaction.getToAcctID()){
    				currentBalance -= amount;
    			}

    		}else if( currentTransaction.getTransacType().equals("Collect")){
    			if(accountID == currentTransaction.getFromAcctID()){
    				currentBalance += amount;
    			}else if (accountID == currentTransaction.getToAcctID()){
    				currentBalance -= amount;
    			}

    		}else if( currentTransaction.getTransacType().equals("Pay-Friend")){
    			if(accountID == currentTransaction.getFromAcctID()){
    				currentBalance += amount;
    			}else if (accountID == currentTransaction.getToAcctID()){
    				currentBalance -= amount;
    			}

    		}else if( currentTransaction.getTransacType().equals("Wire")){
    			if(accountID == currentTransaction.getFromAcctID()){
    				currentBalance += amount;
    			}else if (accountID == currentTransaction.getToAcctID()){
    				currentBalance -= amount;
    			}
    		}

    		else if( currentTransaction.getTransacType().equals("Write-Check")){
    			if(accountID == currentTransaction.getFromAcctID()){
    				currentBalance += amount;
    			}

    		}else if( currentTransaction.getTransacType().equals("Accrue-Interest")){
    			if (accountID == currentTransaction.getToAcctID()){
    				currentBalance -= amount;
    			}

    		}else if( currentTransaction.getTransacType().equals("Monthly Fee")){
    			if (accountID == currentTransaction.getFromAcctID()){
    				currentBalance += amount;
    			}
    		}
    	}
    	initBalance = currentBalance;
    	
    	return initBalance;
		
	}
	
    public class Pair {
		public String name; 
		public String address; 
		
		public Pair(String name, String address) { 
		    this.name = name; 
		    this.address = address; 
		}
		
		public String getName() {
			return name;
		}
		
		public void setName(String name) {
			this.name = name;
		}
		
		public String getAddress() {
			return address;
		}
		
		public void setAddress(String address) {
			this.address = address;
		}
	}

	
	
	public ArrayList<Pair> nameAndAddress(Account account) {
		ArrayList<Pair> nameAndAddress = new ArrayList<Pair>();
		//ArrayList<String> customerTins = new ArrayList<String>();
		String sql1 = "select name, address from Customers where TIN in (select TIN from Ownership where acctID = ?)";
		try {
			Connection con = new dbUtil().getCon();
    		PreparedStatement prst1 = con.prepareStatement(sql1);
    		prst1.setInt(1, account.getAcctID());
    		ResultSet rst1 = prst1.executeQuery();
    		
    		while(rst1.next()){
    			Pair onePair = new Pair(rst1.getString("name"), rst1.getString("address"));
    			nameAndAddress.add(onePair);
    		}
    		}catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
		
		return nameAndAddress;
		
	}
	
	
	
	public boolean over100000(Customer customer) {
		// return true is this customer deposit over $100,000 in this month
		boolean bool = false;
		double totalDeposit = 0;
		ArrayList<Transaction> transactions = new ArrayList<>();
		String sql1 = "select acctID from Ownership where TIN = ?";
		ArrayList<Integer> accounts = new ArrayList<Integer>();
		
		try {
    		PreparedStatement prst1 = con.prepareStatement(sql1);
    		prst1.setString(1, customer.getTIN());
    		ResultSet rst1 = prst1.executeQuery();
    		
    		while(rst1.next()){
    			accounts.add(rst1.getInt("acctID"));   		
    		}
    		}catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}

		for (Integer everyAccount: accounts) {
			String sql2 = "select * from Transactions where toAcctID = ? and (transacType = 'Deposit' or transacType = 'Wire' or transacType = 'Transfer')";
        	try {
        		PreparedStatement prst2 = con.prepareStatement(sql2);
        		prst2.setInt(1, everyAccount);
        		ResultSet rst2 = prst2.executeQuery();
        		
        		while(rst2.next()){
        			double amountOfThisTransaction = rst2.getDouble("amount");
        			totalDeposit += amountOfThisTransaction;      		
        		}
        		}catch (SQLException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		}
		}
		if (totalDeposit >= 10000) {
			bool = true;
		}		
		
		return bool;
	}
	
	
	public boolean alreadyAddedFee(Account pocketAccount) {
		// return true is this customer deposit over $100,000 in this month
		boolean bool = false;

			String sql2 = "select * from Transactions where fromAcctID = ? and transacType = ? ";
        	try {
        		PreparedStatement prst2 = con.prepareStatement(sql2);
        		prst2.setInt(1, pocketAccount.getAcctID());
        		prst2.setString(2, "Monthly Fee");
        		ResultSet rst2 = prst2.executeQuery();
        		if(rst2.next()){
        			bool = true;
        		}
        		}catch (SQLException e) {
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		}
		return bool;
	}
	
	
	public ArrayList<Customer> customersOver100000(){
		ArrayList<Customer> customers = new ArrayList<Customer>();
		String sql1 = "select * from Customers";
    	try {
    		PreparedStatement prst1 = con.prepareStatement(sql1);
    		ResultSet rst1 = prst1.executeQuery();
    		
    		while(rst1.next()){
    			Customer oneCustomer = new Customer();
    			oneCustomer.setTIN(rst1.getString("TIN"));
    			oneCustomer.setUsername(rst1.getString("username"));
    			oneCustomer.setName(rst1.getString("name"));
    			oneCustomer.setAddress(rst1.getString("address"));
    			oneCustomer.setPIN(rst1.getString("PIN"));
    			
    			if(over100000(oneCustomer)) {
    				customers.add(oneCustomer);
    			}
    		
    		}
    		}catch (SQLException e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    	return customers;
	}

}
