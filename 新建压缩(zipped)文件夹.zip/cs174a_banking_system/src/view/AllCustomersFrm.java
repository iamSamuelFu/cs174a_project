package view;

import java.awt.EventQueue;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JButton;

import dao.AccountDao;
import dao.CustomerDao;
import model.Account;
import model.Customer;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AllCustomersFrm extends JFrame {
	private JComboBox comboBox;
	public ArrayList<Customer> customers;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					AllCustomersFrm frame = new AllCustomersFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public AllCustomersFrm() {
		setTitle("Customer List");
		setBounds(100, 100, 450, 300);
		setLocationRelativeTo(null);
		JLabel lblPleaseSelectA = new JLabel("Please Select A Customer:");
		lblPleaseSelectA.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		////////////////////////
		CustomerDao customerDao = new CustomerDao();
		customers = customerDao.getAllCustomers();
		DefaultComboBoxModel list = new DefaultComboBoxModel();
		for(Customer cst : customers){
			list.addElement("[Name: "+cst.getName()+"][TIN: "+cst.getTIN()+"]");
		}
		comboBox = new JComboBox();
		comboBox.setModel(list);
		/////////////////////////
		JButton btnSelect = new JButton("Select");
		btnSelect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				submitCustomer(ae);
			}
		});
		btnSelect.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(159)
							.addComponent(btnSelect))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(23)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 382, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblPleaseSelectA))))
					.addContainerGap(27, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(33)
					.addComponent(lblPleaseSelectA)
					.addGap(42)
					.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(42)
					.addComponent(btnSelect)
					.addContainerGap(66, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);

	}
	protected void submitCustomer(ActionEvent ae) {
		// TODO Auto-generated method stub
		String selectedCustomer = comboBox.getSelectedItem().toString();
		String customerTIN = selectedCustomer.replaceAll("[^0-9]", "");
		Customer customerTmp = null;
		for (int i = 0; i < customers.size(); i++) {
			if (customerTIN.equals(customers.get(i).getTIN())){
				customerTmp = customers.get(i);
			}
		}
		this.dispose();
		new AssociatedAccountsFrm(customerTmp).setVisible(true);
		
	}

}
