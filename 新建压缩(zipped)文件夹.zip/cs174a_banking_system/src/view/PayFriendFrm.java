package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JInternalFrame;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JComboBox;

import utility.stringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

import model.Account;
import model.Customer;
import model.Transaction;
import dao.AccountDao;
import dao.CustomerDao;
import dao.TransactionDao;
import utility.dateUtil;

public class PayFriendFrm extends JInternalFrame {

	private JPanel contentPane;
	private JTextField payFriendAmountTextField;
	private JComboBox payFriendFromAccountComboBox;
	public static Object customerObject;
	public ArrayList<Account> accounts;
	public ArrayList<Account> allAccounts;
	private JLabel lblToAccount;
	private JTextField toAccountTextField;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					PayFriendFrm frame = new PayFriendFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public PayFriendFrm(Object customerObject) {
		this.customerObject = customerObject;
		CustomerDao customerDao = new CustomerDao();
		Customer customer = (Customer) customerObject;
		accounts = customerDao.getAccounts(customer);
		accounts.removeIf(a -> !("Pocket".equals(a.getType())));
		
		setTitle("PayFriend");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 506, 345);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setClosable(true);
		setIconifiable(true);
		JLabel lblpayFriendAmount = new JLabel("Pay-Friend Amount:");
		lblpayFriendAmount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		payFriendAmountTextField = new JTextField();
		payFriendAmountTextField.setColumns(10);
		
		JButton btnNewButton = new JButton("Pay-Friend!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				submitPayFriend(ae);
			}
		});
		btnNewButton.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JLabel lblFromAccount = new JLabel("From Account:");
		lblFromAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		DefaultComboBoxModel list1 = new DefaultComboBoxModel();
		DefaultComboBoxModel list2 = new DefaultComboBoxModel();
		for(Account acct : accounts){
			list1.addElement(Integer.toString(acct.getAcctID())+" ["+acct.getType()+"]");
			list2.addElement(Integer.toString(acct.getAcctID())+" ["+acct.getType()+"]");
		}
		payFriendFromAccountComboBox = new JComboBox();
		payFriendFromAccountComboBox.setModel(list1);
		
		lblToAccount = new JLabel("To Account #:");
		lblToAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		toAccountTextField = new JTextField();
		toAccountTextField.setColumns(10);
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(34)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(lblpayFriendAmount)
								.addComponent(lblFromAccount)
								.addComponent(lblToAccount))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(payFriendFromAccountComboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(payFriendAmountTextField, GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE)
								.addComponent(toAccountTextField)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(175)
							.addComponent(btnNewButton)))
					.addContainerGap(94, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(44)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblpayFriendAmount)
						.addComponent(payFriendAmountTextField, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
					.addGap(33)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblFromAccount)
						.addComponent(payFriendFromAccountComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblToAccount)
						.addComponent(toAccountTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
					.addComponent(btnNewButton)
					.addGap(36))
		);
		contentPane.setLayout(gl_contentPane);
	}

	protected void submitPayFriend(ActionEvent ae) {
		// TODO Auto-generated method stub
		String payFriendAmount = payFriendAmountTextField.getText().toString();
		String selectedAcctFrom = payFriendFromAccountComboBox.getSelectedItem().toString();
		String selectedAcctTo = toAccountTextField.getText().toString();;
		
		//String numberOnly= selectedAcct.replaceAll("[^0-9]", "");
		if(stringUtil.isEmpty(payFriendAmount)){
			JOptionPane.showMessageDialog(this, "Please Enter the Amount You Want To Pay-Friend");
			return;
		}
		if(stringUtil.isEmpty(selectedAcctTo)){
			JOptionPane.showMessageDialog(this, "Please Enter the Account # of the Account You To Pay-Friend to");
			return;
		}
		
		int acctIDFrom = Integer.parseInt(selectedAcctFrom.replaceAll("[^0-9]", ""));
		int acctIDTo = Integer.parseInt(selectedAcctTo.replaceAll("[^0-9]", ""));
		
		if(acctIDFrom == acctIDTo){
			JOptionPane.showMessageDialog(this, "Please Select A Different Account To Pay-Friend");
			return;
		}
		
		
		AccountDao accountDao = new AccountDao();
		//accounts.removeIf(a -> (acctID == a.getAcctID()));
		Account accountFrom = new Account();
		Account accountTo = null;
		for (int i = 0; i < accounts.size(); i++){
			if (accounts.get(i).getAcctID() == acctIDFrom){
			   accountFrom = accounts.get(i);
			}
		}
		
		CustomerDao customerDao = new CustomerDao();
		Customer customer = (Customer) customerObject;
		allAccounts = customerDao.getAllAccounts();
		allAccounts.removeIf(a -> !("Pocket".equals(a.getType())));
		for (int i = 0; i < allAccounts.size(); i++){
			if (allAccounts.get(i).getAcctID() == acctIDTo){
				   accountTo = allAccounts.get(i);
			}
		}
		
		if(accountTo == null){
			JOptionPane.showMessageDialog(this, "Invalid Account");
			return;
		}
		if(accountFrom.getBalance() < Double.valueOf(payFriendAmount)){
			JOptionPane.showMessageDialog(this, "Insufficient Fund");
			return;
		}
		if(!accountDao.payFriend(accountFrom, accountTo, Double.valueOf(payFriendAmount))){
			JOptionPane.showMessageDialog(this, "PayFriend Fail");
		}else{
			JOptionPane.showMessageDialog(this, "PayFriend Successful");
			if((accountFrom.getBalance()-Double.valueOf(payFriendAmount)) <= 0.01){
				AccountDao closeDao = new AccountDao();
				if(closeDao.closeAccount(accountFrom)){
					JOptionPane.showMessageDialog(this, "Account is closed!");
				}
			}
		}
		
		Transaction transac = new Transaction();
		transac.setFromAcctID(acctIDFrom);
		transac.setToAcctID(acctIDTo);
		transac.setTransacType("Pay-Friend");
		transac.setAmount(Double.valueOf(payFriendAmount));
		dateUtil u = new dateUtil();
		transac.setDates(u.getSysDate());
		TransactionDao transactionDao = new TransactionDao();
		transactionDao.insertTransaction(transac);
		
		this.dispose();
		
	}
}

