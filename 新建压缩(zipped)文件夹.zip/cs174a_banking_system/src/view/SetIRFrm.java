package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import dao.AccountDao;
import utility.stringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SetIRFrm extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JComboBox comboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SetIRFrm frame = new SetIRFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SetIRFrm() {
		setTitle("Set New Interest Rate");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
		JLabel lblType = new JLabel("Type:");
		lblType.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		
		comboBox = new JComboBox();
		comboBox.setFont(new Font("Franklin Gothic Medium", Font.ITALIC, 18));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Checking - Student", "Checking - Interest", "Savings", "Pocket"}));
		
		JLabel lblNewRate = new JLabel("New Rate:");
		lblNewRate.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		
		textField = new JTextField();
		textField.setColumns(10);
		
		JButton btnSet = new JButton("Set!");
		btnSet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				submitNewIR(ae);
			}
		});
		btnSet.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(72)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNewRate)
							.addGap(18)
							.addComponent(textField))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblType)
							.addGap(18)
							.addComponent(comboBox, GroupLayout.PREFERRED_SIZE, 217, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(66, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(177)
					.addComponent(btnSet)
					.addContainerGap(180, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(44)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(comboBox, Alignment.LEADING)
						.addComponent(lblType, Alignment.LEADING))
					.addGap(40)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addComponent(textField)
						.addComponent(lblNewRate, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(38)
					.addComponent(btnSet)
					.addGap(34))
		);
		contentPane.setLayout(gl_contentPane);
	}

	protected void submitNewIR(ActionEvent ae) {
		// TODO Auto-generated method stub
		String acctType = comboBox.getSelectedItem().toString();
		String newIR = textField.getText().toString();
		
		if(stringUtil.isEmpty(newIR)){
			JOptionPane.showMessageDialog(this, "Please Enter the New Interest Rate");
			return;
		}
		
		AccountDao accountDao = new AccountDao();
		if(!accountDao.setIR(acctType, Double.valueOf(newIR))){
			JOptionPane.showMessageDialog(this, "Something went wrong...");
		}else{
			JOptionPane.showMessageDialog(this, "Success!");
		}
		
		this.dispose();
	}
}
