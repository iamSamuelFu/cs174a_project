package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JInternalFrame;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JComboBox;

import utility.stringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

import model.Account;
import model.Customer;
import model.Transaction;
import dao.AccountDao;
import dao.CustomerDao;
import dao.TransactionDao;
import utility.dateUtil;

public class CollectFrm extends JInternalFrame {

	private JPanel contentPane;
	private JTextField collectAmountTextField;
	private JComboBox collectAccountComboBox;
	public static Object customerObject;
	public ArrayList<Account> accounts;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					CollectFrm frame = new CollectFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public CollectFrm(Object customerObject) {
		this.customerObject = customerObject;
		CustomerDao customerDao = new CustomerDao();
		Customer customer = (Customer) customerObject;
		accounts = customerDao.getAccounts(customer);
		accounts.removeIf(a -> !("Pocket".equals(a.getType())));
		
		setTitle("Collect");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 506, 345);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setClosable(true);
		setIconifiable(true);
		JLabel lblCollectAmount = new JLabel("Collect Amount:");
		lblCollectAmount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		collectAmountTextField = new JTextField();
		collectAmountTextField.setColumns(10);
		
		JButton btnNewButton = new JButton("Collect!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				submitCollect(ae);
			}
		});
		btnNewButton.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JLabel lblAccount = new JLabel("Pocket Account:");
		lblAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		DefaultComboBoxModel list = new DefaultComboBoxModel();
		for(Account acct : accounts){
			list.addElement(Integer.toString(acct.getAcctID())+" ["+acct.getType()+"]");
		}
		collectAccountComboBox = new JComboBox();
		collectAccountComboBox.setModel(list);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(34)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblAccount)
						.addComponent(lblCollectAmount))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
							.addComponent(collectAccountComboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(collectAmountTextField, GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE)))
					.addContainerGap(80, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(44)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblCollectAmount)
						.addComponent(collectAmountTextField, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
					.addGap(33)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAccount)
						.addComponent(collectAccountComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(63)
					.addComponent(btnNewButton)
					.addContainerGap(77, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

	protected void submitCollect(ActionEvent ae) {
		// TODO Auto-generated method stub
		String collectAmount = collectAmountTextField.getText().toString();
		String selectedAcct = collectAccountComboBox.getSelectedItem().toString();
		
		//String numberOnly= selectedAcct.replaceAll("[^0-9]", "");
		if(stringUtil.isEmpty(collectAmount)){
			JOptionPane.showMessageDialog(this, "Please Enter the Amount You Want To Collect");
			return;
		}
		int acctID = Integer.parseInt(selectedAcct.replaceAll("[^0-9]", ""));
		AccountDao accountDao = new AccountDao();
		//accounts.removeIf(a -> (acctID == a.getAcctID()));
		Account accountTmp = new Account();
		for (int i = 0; i < accounts.size(); i++) {
			if (accounts.get(i).getAcctID() == acctID){
			   accountTmp = accounts.get(i);
			}
		}
		double linkedAcctBalance = accountDao.collect(accountTmp, Double.valueOf(collectAmount));
		
		if(linkedAcctBalance == -2){
			JOptionPane.showMessageDialog(this, "Insufficient Fund");
			return;
		}
		
		if(linkedAcctBalance == -1){
			JOptionPane.showMessageDialog(this, "Collect Fail");
		}else{
			JOptionPane.showMessageDialog(this, "Collect Successful");
		}
		
		Transaction transac = new Transaction();
		transac.setFromAcctID(acctID);
		transac.setToAcctID(accountTmp.getLinkID());
		transac.setTransacType("Collect");
		transac.setAmount(Double.valueOf(collectAmount));
		dateUtil u = new dateUtil();
		transac.setDates(u.getSysDate());
		TransactionDao transactionDao = new TransactionDao();
		transactionDao.insertTransaction(transac);
		
		this.dispose();
		
	}
}
