package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JDesktopPane;
import javax.swing.JOptionPane;

import dao.CustomerDao;
import model.Account;
import model.Customer;

import java.awt.Color;
import java.text.DecimalFormat;
import java.util.ArrayList;

import javax.swing.ImageIcon;

public class CustomerMainFrm extends JFrame {

	private JPanel contentPane;
	private JDesktopPane desktopPane;
	public static Object customerObject;
	

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					CustomerMainFrm frame = new CustomerMainFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public CustomerMainFrm(Object customerObject) {
		this.customerObject = customerObject;
		setTitle("Customer Interface");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 778, 569);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Actions");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmDeposit = new JMenuItem("Deposit");
		mntmDeposit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				deposit(ae);
			}
		});
		mnNewMenu.add(mntmDeposit);
		
		JMenuItem mntmTopup = new JMenuItem("Top-Up");
		mntmTopup.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				topup(ae);
			}
		});
		mnNewMenu.add(mntmTopup);
		
		JMenuItem mntmWithdrawal = new JMenuItem("Withdrawal");
		mntmWithdrawal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				withdrawl(ae);
			}
		});
		mnNewMenu.add(mntmWithdrawal);
		
		JMenuItem mntmPurchase = new JMenuItem("Purchase");
		mntmPurchase.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				purchase(ae);
			}
		});
		mnNewMenu.add(mntmPurchase);
		
		JMenuItem mntmTransfer = new JMenuItem("Transfer");
		mntmTransfer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				transfer(ae);
			}
		});
		mnNewMenu.add(mntmTransfer);
		
		JMenuItem mntmCollect = new JMenuItem("Collect");
		mntmCollect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				collect(ae);
			}
		});
		mnNewMenu.add(mntmCollect);
		
		JMenuItem mntmWire = new JMenuItem("Wire");
		mntmWire.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				wire(ae);
			}
		});
		mnNewMenu.add(mntmWire);
		
		JMenuItem mntmPayfriend = new JMenuItem("Pay-Friend");
		mntmPayfriend.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				payFriend(ae);
			}
		});
		mnNewMenu.add(mntmPayfriend);
		
		JMenu mnSetting = new JMenu("Setting");
		menuBar.add(mnSetting);
		
		JMenuItem mntmResetPin = new JMenuItem("Reset PIN");
		mntmResetPin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				resetPIN(ae);
			}
		});
		mntmResetPin.setIcon(new ImageIcon(CustomerMainFrm.class.getResource("/javax/swing/plaf/metal/icons/ocean/computer.gif")));
		mnSetting.add(mntmResetPin);
		
		JMenuItem mntmLogOut = new JMenuItem("Log Out");
		mntmLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				logout(ae);
			}
		});
		mntmLogOut.setIcon(new ImageIcon(CustomerMainFrm.class.getResource("/javax/swing/plaf/basic/icons/JavaCup16.png")));
		mnSetting.add(mntmLogOut);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		desktopPane = new JDesktopPane();
		desktopPane.setBackground(Color.PINK);
		contentPane.add(desktopPane, BorderLayout.CENTER);
		
		JLabel lblAccountSummary = new JLabel("Account Summary");
		lblAccountSummary.setFont(new Font("Franklin Gothic Medium", Font.BOLD | Font.ITALIC, 28));
		lblAccountSummary.setBounds(250, 23, 255, 110);
		desktopPane.add(lblAccountSummary);
		
		JLabel lblprimaryOwner = new JLabel("*Primary Owner");
		lblprimaryOwner.setFont(new Font("Franklin Gothic Medium", Font.ITALIC, 17));
		lblprimaryOwner.setBounds(595, 414, 127, 42);
		desktopPane.add(lblprimaryOwner);
		
		JButton btnRefresh = new JButton("Refresh");
		btnRefresh.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				refresh(ae);
			}
		});
		btnRefresh.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 17));
		btnRefresh.setIcon(new ImageIcon(CustomerMainFrm.class.getResource("/com/sun/javafx/scene/web/skin/Undo_16x16_JFX.png")));
		btnRefresh.setBounds(595, 398, 127, 25);
		desktopPane.add(btnRefresh);
		setLocationRelativeTo(null);
		
		CustomerDao customerDao = new CustomerDao();
		Customer customer = (Customer) customerObject;
		ArrayList<Account> accounts = customerDao.getAccounts(customer);
		
		if(accounts.isEmpty()){
			JOptionPane.showMessageDialog(this,"No Accounts Available");
			System.exit(0);
		}else{
			int size = accounts.size();
			JOptionPane.showMessageDialog(this,"You have "+Integer.toString(size)+" accounts available.");
		}
		
		int y = 117;
		for(Account acct : accounts){
			DecimalFormat df = new DecimalFormat("#.00");
			String str = "[Account Number: "+Integer.toString(acct.getAcctID())+"]["+acct.getType()+"][Balance: "+df.format(acct.getBalance())+"]";
			if(acct.getPrimaryTIN().equals(customer.getTIN())){
				str = "*"+str;
			}
			JLabel lblAcctSum = new JLabel(str);
			lblAcctSum.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
			lblAcctSum.setBounds(124, y, 477, 51);
			desktopPane.add(lblAcctSum);
			y = y+60;
		}
	}

	protected void logout(ActionEvent ae) {
		// TODO Auto-generated method stub
		LoginFrm loginFrm = new LoginFrm();
		loginFrm.setVisible(true);
		this.dispose();
	}

	protected void payFriend(ActionEvent ae) {
		// TODO Auto-generated method stub
		PayFriendFrm payFriendFrm = new PayFriendFrm((Customer) customerObject);
		payFriendFrm.setVisible(true);
		desktopPane.add(payFriendFrm);
		payFriendFrm.moveToFront();
	}

	protected void collect(ActionEvent ae) {
		// TODO Auto-generated method stub
		CollectFrm collectFrm = new CollectFrm((Customer) customerObject);
		collectFrm.setVisible(true);
		desktopPane.add(collectFrm);
		collectFrm.moveToFront();
	}

	protected void purchase(ActionEvent ae) {
		// TODO Auto-generated method stub
		PurchaseFrm purchaseFrm = new PurchaseFrm((Customer) customerObject);
		purchaseFrm.setVisible(true);
		desktopPane.add(purchaseFrm);
		purchaseFrm.moveToFront();
	}

	protected void topup(ActionEvent ae) {
		// TODO Auto-generated method stub
		TopUpFrm topupFrm = new TopUpFrm((Customer) customerObject);
		topupFrm.setVisible(true);
		desktopPane.add(topupFrm);
		topupFrm.moveToFront();
	}

	protected void resetPIN(ActionEvent ae) {
		// TODO Auto-generated method stub
		setPINFrm spf = new setPINFrm((Customer) customerObject);
		spf.setVisible(true);
		desktopPane.add(spf);
		spf.moveToFront();
	}

	protected void wire(ActionEvent ae) {
		// TODO Auto-generated method stub
		WireFrm wireFrm = new WireFrm((Customer) customerObject);
		wireFrm.setVisible(true);
		desktopPane.add(wireFrm);
		wireFrm.moveToFront();
	}

	protected void transfer(ActionEvent ae) {
		// TODO Auto-generated method stub
		TransferFrm transferFrm = new TransferFrm((Customer) customerObject);
		transferFrm.setVisible(true);
		desktopPane.add(transferFrm);
		transferFrm.moveToFront();
	}

	protected void withdrawl(ActionEvent ae) {
		// TODO Auto-generated method stub
		WithdrawlFrm withdrawlFrm = new WithdrawlFrm((Customer) customerObject);
		withdrawlFrm.setVisible(true);
		desktopPane.add(withdrawlFrm);
		withdrawlFrm.moveToFront();
	}

	protected void refresh(ActionEvent ae) {
		// TODO Auto-generated method stub
		Customer customer = (Customer)customerObject;
		new CustomerMainFrm(customer).setVisible(true);
		this.dispose();
	}

	protected void deposit(ActionEvent ae) {
		// TODO Auto-generated method stub
		DepositFrm depositFrm = new DepositFrm((Customer) customerObject);
		depositFrm.setVisible(true);
		desktopPane.add(depositFrm);
		depositFrm.moveToFront();
	}
}
