package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

import dao.CustomerDao;
import model.Account;
import model.Customer;

public class AssociatedAccountsFrm extends JFrame {

	private JPanel contentPane;
	private JList list_1;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					AssociatedAccountsFrm frame = new AssociatedAccountsFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public AssociatedAccountsFrm(Customer customer) {
		setTitle("Associated Accounts");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 561, 435);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		JList list = new JList();
		DefaultListModel listModel;
	    listModel = new DefaultListModel();
	    listModel.addElement("List of Accounts Associated With "+customer.getName()+" :");
	    listModel.addElement("-----------------------------------------------------------------------------------------");
	    CustomerDao customerDao = new CustomerDao();
		ArrayList<Account> accounts = customerDao.getAccounts(customer);
		for(Account acct : accounts){
			String str = "[Account Number: "+Integer.toString(acct.getAcctID())+"]["+acct.getType();
			if(acct.isActive()){
				str = str+"][Status: OPEN]";
			}else{
				str = str+"][Status: CLOSED]";
			}
			listModel.addElement(str);
		}
		
	    //Create the list and put it in a scroll pane.
	    list_1 = new JList(listModel);
	    list_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
	    list_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    list_1.setSelectedIndex(0);
	    list_1.setVisibleRowCount(5);
//	    JScrollPane listScrollPane = new JScrollPane(list);
		scrollPane.setViewportView(list_1);
	}

}
