package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;

import java.awt.Color;

import javax.swing.JButton;

import java.awt.Font;

import javax.swing.LayoutStyle.ComponentPlacement;

import model.Customer;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.JDesktopPane;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import dao.AccountDao;

public class BankTellerFrm extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					BankTellerFrm frame = new BankTellerFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public BankTellerFrm() {
		setTitle("Bank Teller Interface");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 948, 403);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnSetting = new JMenu("Setting");
		mnSetting.setIcon(new ImageIcon(BankTellerFrm.class.getResource("/com/sun/java/swing/plaf/windows/icons/Computer.gif")));
		menuBar.add(mnSetting);
		
		JMenuItem mntmSystemDate = new JMenuItem("System Date");
		mntmSystemDate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				setNewDate(ae);
			}
		});
		mnSetting.add(mntmSystemDate);
		
		JMenuItem mntmInterestRate = new JMenuItem("Interest Rate");
		mntmInterestRate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				setNewIR(ae);
			}
		});
		mnSetting.add(mntmInterestRate);
		contentPane = new JPanel();
		contentPane.setBackground(Color.PINK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
		JButton btnCheckTransaction = new JButton("Check Transaction");
		btnCheckTransaction.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				checkTransaction(ae);
			}
		});
		btnCheckTransaction.setBackground(Color.WHITE);
		btnCheckTransaction.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		
		JButton btnGenerateMonthlyStatement = new JButton("Generate Monthly Statement");
		btnGenerateMonthlyStatement.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				MonthlyStatement(ae);
			}
		});
		btnGenerateMonthlyStatement.setBackground(Color.WHITE);
		btnGenerateMonthlyStatement.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		
		JButton btnListClosedAccounts = new JButton("List Closed Accounts");
		btnListClosedAccounts.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				closedAccounts(ae);
			}
		});
		btnListClosedAccounts.setBackground(Color.WHITE);
		btnListClosedAccounts.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		
		JButton btnAddInterest = new JButton("Add Interest");
		btnAddInterest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				addInterest(ae);
			}
		});
		btnAddInterest.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		btnAddInterest.setBackground(Color.WHITE);
		
		JButton btnCustomerReport = new JButton("Customer Report");
		btnCustomerReport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				customerReport(ae);
			}
		});
		btnCustomerReport.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		btnCustomerReport.setBackground(Color.WHITE);
		
		JButton btnGenerateGovernmentDrug = new JButton("Government Drug and Tax Evasion Report");
		btnGenerateGovernmentDrug.setBackground(Color.WHITE);
		btnGenerateGovernmentDrug.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				DTER(ae);
			}
		});
		btnGenerateGovernmentDrug.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JButton btnNewButton = new JButton("Create Account");
		btnNewButton.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				createAccount(ae);
			}
		});
		
		JButton btnNewButton_1 = new JButton("Delete Closed Accounts and Customers");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				deleteAcctCustomer(ae);
			}
		});
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JButton btnNewButton_2 = new JButton("Delete Transactions");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				deleteTransaction(ae);
			}
		});
		btnNewButton_2.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		btnNewButton_2.setBackground(Color.WHITE);
		
		JDesktopPane desktopPane = new JDesktopPane();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap(58, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(btnNewButton)
									.addGap(18)
									.addComponent(btnNewButton_1)
									.addGap(18)
									.addComponent(btnNewButton_2))
								.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING, false)
									.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(btnCheckTransaction)
										.addGap(18)
										.addComponent(btnGenerateMonthlyStatement)
										.addGap(18)
										.addComponent(btnListClosedAccounts))
									.addGroup(gl_contentPane.createSequentialGroup()
										.addComponent(btnGenerateGovernmentDrug, 0, 0, Short.MAX_VALUE)
										.addGap(18)
										.addComponent(btnCustomerReport)
										.addGap(18)
										.addComponent(btnAddInterest)))))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(27)
							.addComponent(desktopPane, GroupLayout.PREFERRED_SIZE, 1, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(81, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(22)
					.addComponent(desktopPane, GroupLayout.PREFERRED_SIZE, 1, GroupLayout.PREFERRED_SIZE)
					.addGap(42)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCheckTransaction)
						.addComponent(btnGenerateMonthlyStatement, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnListClosedAccounts, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE))
					.addGap(57)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAddInterest)
						.addComponent(btnCustomerReport)
						.addComponent(btnGenerateGovernmentDrug, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE))
					.addGap(56)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton)
						.addComponent(btnNewButton_1, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton_2))
					.addContainerGap(62, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

	protected void MonthlyStatement(ActionEvent ae) {
		// TODO Auto-generated method stub
		StatementCustomerFrm scf = new StatementCustomerFrm();
		scf.setVisible(true);
		scf.toFront();
	}

	protected void DTER(ActionEvent ae) {
		// TODO Auto-generated method stub
		DTERFrm dterFrm = new DTERFrm();
		dterFrm.setVisible(true);
		dterFrm.toFront();
	}

	protected void createAccount(ActionEvent ae) {
		// TODO Auto-generated method stub
		CreateAccountFrm createAccountFrm = new CreateAccountFrm();
		createAccountFrm.setVisible(true);
		createAccountFrm.toFront();
	}

	protected void deleteAcctCustomer(ActionEvent ae) {
		// TODO Auto-generated method stub
		AccountDao accountDao = new AccountDao();
		boolean result = accountDao.deleteAcctCustomer();
		if(!result){
			JOptionPane.showMessageDialog(this, "Fail to delete!");
		}else{
			JOptionPane.showMessageDialog(this, "Successfully deleted!");
		}
		
	}

	protected void addInterest(ActionEvent ae) {
		// TODO Auto-generated method stub
		AccountDao accountDao = new AccountDao();
		if(!accountDao.addInterest()){
			JOptionPane.showMessageDialog(this, "Fail to add interest!");
		}else{
			JOptionPane.showMessageDialog(this, "Successfully added!");
		}
	}

	protected void deleteTransaction(ActionEvent ae) {
		// TODO Auto-generated method stub
		AccountDao accountDao = new AccountDao();
		if(!accountDao.deleteTransaction()){
			JOptionPane.showMessageDialog(this, "Fail to delete transactions!");
		}else{
			JOptionPane.showMessageDialog(this, "Successfully deleted!");
		}
	}

	protected void setNewDate(ActionEvent ae) {
		// TODO Auto-generated method stub
		SetDateFrm setDateFrm = new SetDateFrm();
		setDateFrm.setVisible(true);
		setDateFrm.toFront();
	}

	protected void setNewIR(ActionEvent ae) {
		// TODO Auto-generated method stub
		SetIRFrm setIRFrm = new SetIRFrm();
		setIRFrm.setVisible(true);
		setIRFrm.toFront();
	}

	protected void customerReport(ActionEvent ae) {
		// TODO Auto-generated method stub
		AllCustomersFrm allCustomersFrm = new AllCustomersFrm();
		allCustomersFrm.setVisible(true);
		allCustomersFrm.toFront();
	}

	protected void closedAccounts(ActionEvent ae) {
		// TODO Auto-generated method stub
		ClosedAccountsFrm closedAccountsFrm = new ClosedAccountsFrm();
		closedAccountsFrm.setVisible(true);
		closedAccountsFrm.toFront();
		
	}

	protected void checkTransaction(ActionEvent ae) {
		// TODO Auto-generated method stub
		CheckTransactionFrm checkTransactionFrm = new CheckTransactionFrm();
		checkTransactionFrm.setVisible(true);
		checkTransactionFrm.toFront();
		
	}
}
