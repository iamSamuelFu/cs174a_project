package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JOptionPane;

import dao.AccountDao;
import dao.CustomerDao;
import dao.TransactionDao;
import model.Account;
import model.Customer;
import model.Transaction;
import utility.dateUtil;
import utility.stringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

public class CreateAccountFrm extends JFrame {

	private JPanel contentPane;
	private JTextField balanceTextField;
	private JTextField branchTextField;
	private JTextField usernameTextField;
	private JTextField nameTextField;
	private JTextField TINTextField;
	private JTextField PINTextField;
	private JTextField addressTextField;
	private JTextField otherTINTextField;
	private JComboBox typeComboBox;
	private JComboBox subtypeComboBox;
	private JTextField IDTextField;
	private JComboBox linkIDComboBox;
	public ArrayList<Account> allAccounts;
	public ArrayList<Account> nonPocketAccounts;
	public ArrayList<Customer> allCustomers;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					CreateAccountFrm frame = new CreateAccountFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public CreateAccountFrm() {
		setTitle("Create Account");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 675, 592);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
		JLabel lblAccountInformation = new JLabel("Account Information");
		lblAccountInformation.setBounds(32, 18, 193, 26);
		lblAccountInformation.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		
		JLabel lblNewLabel = new JLabel("Balance");
		lblNewLabel.setBounds(193, 63, 69, 24);
		lblNewLabel.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		balanceTextField = new JTextField();
		balanceTextField.setBounds(277, 62, 133, 27);
		balanceTextField.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		balanceTextField.setColumns(10);
		
		JLabel lblBranch = new JLabel("Branch");
		lblBranch.setBounds(193, 108, 69, 24);
		lblBranch.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		branchTextField = new JTextField();
		branchTextField.setBounds(277, 107, 133, 27);
		branchTextField.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		branchTextField.setColumns(10);
		
		JLabel lblT = new JLabel("Type");
		lblT.setBounds(449, 63, 49, 24);
		lblT.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JLabel lblSubtyoe = new JLabel("Subtype");
		lblSubtyoe.setBounds(422, 108, 79, 24);
		lblSubtyoe.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		typeComboBox = new JComboBox();
		typeComboBox.setBounds(510, 62, 109, 27);
		typeComboBox.setFont(new Font("Franklin Gothic Medium", Font.ITALIC, 18));
		typeComboBox.setModel(new DefaultComboBoxModel(new String[] {"Checking", "Savings", "Pocket"}));
		
		subtypeComboBox = new JComboBox();
		subtypeComboBox.setBounds(510, 107, 109, 27);
		subtypeComboBox.setFont(new Font("Franklin Gothic Medium", Font.ITALIC, 18));
		subtypeComboBox.setModel(new DefaultComboBoxModel(new String[] {"", "Student", "Interest"}));
		
		JLabel lblPrimaryUserInformation = new JLabel("Primary User Information");
		lblPrimaryUserInformation.setBounds(32, 193, 260, 26);
		lblPrimaryUserInformation.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setBounds(32, 233, 87, 24);
		lblUsername.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		usernameTextField = new JTextField();
		usernameTextField.setBounds(137, 232, 148, 27);
		usernameTextField.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		usernameTextField.setColumns(10);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(328, 233, 65, 24);
		lblName.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		nameTextField = new JTextField();
		nameTextField.setBounds(411, 232, 148, 27);
		nameTextField.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		nameTextField.setColumns(10);
		
		JLabel lblTin = new JLabel("TIN");
		lblTin.setBounds(32, 286, 37, 24);
		lblTin.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		TINTextField = new JTextField();
		TINTextField.setBounds(137, 285, 148, 27);
		TINTextField.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		TINTextField.setColumns(10);
		
		JLabel lblPin = new JLabel("PIN");
		lblPin.setBounds(356, 286, 37, 24);
		lblPin.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		PINTextField = new JTextField();
		PINTextField.setBounds(411, 285, 148, 27);
		PINTextField.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		PINTextField.setColumns(10);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setBounds(32, 331, 69, 24);
		lblAddress.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		addressTextField = new JTextField();
		addressTextField.setBounds(137, 330, 422, 27);
		addressTextField.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		addressTextField.setColumns(10);
		
		JLabel lblonlyFillOut = new JLabel("*Fill out only TIN if user already exists");
		lblonlyFillOut.setBounds(365, 375, 254, 19);
		lblonlyFillOut.setFont(new Font("Franklin Gothic Medium", Font.ITALIC, 16));
		
		JLabel lblOtherUserInformation = new JLabel("Other User TIN (seperated by ';')");
		lblOtherUserInformation.setBounds(32, 421, 330, 26);
		lblOtherUserInformation.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 22));
		
		otherTINTextField = new JTextField();
		otherTINTextField.setBounds(32, 465, 422, 27);
		otherTINTextField.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		otherTINTextField.setColumns(10);
		
		JButton btnCreate = new JButton("Create!");
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				submitCreate(ae);
			}
		});
		btnCreate.setBounds(507, 418, 112, 74);
		btnCreate.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 16));
		contentPane.setLayout(null);
		contentPane.add(lblonlyFillOut);
		contentPane.add(lblAccountInformation);
		contentPane.add(lblNewLabel);
		contentPane.add(balanceTextField);
		contentPane.add(lblBranch);
		contentPane.add(branchTextField);
		contentPane.add(lblSubtyoe);
		contentPane.add(lblT);
		contentPane.add(typeComboBox);
		contentPane.add(subtypeComboBox);
		contentPane.add(lblAddress);
		contentPane.add(addressTextField);
		contentPane.add(lblPrimaryUserInformation);
		contentPane.add(lblTin);
		contentPane.add(TINTextField);
		contentPane.add(lblUsername);
		contentPane.add(usernameTextField);
		contentPane.add(lblName);
		contentPane.add(lblPin);
		contentPane.add(PINTextField);
		contentPane.add(nameTextField);
		contentPane.add(otherTINTextField);
		contentPane.add(lblOtherUserInformation);
		contentPane.add(btnCreate);
		
		JLabel lblId = new JLabel("ID");
		lblId.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		lblId.setBounds(32, 63, 69, 24);
		contentPane.add(lblId);
		
		IDTextField = new JTextField();
		IDTextField.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		IDTextField.setColumns(10);
		IDTextField.setBounds(82, 62, 87, 27);
		contentPane.add(IDTextField);
		
		JLabel lblLinkId = new JLabel("Link ID");
		lblLinkId.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		lblLinkId.setBounds(12, 108, 69, 24);
		contentPane.add(lblLinkId);
		
		CustomerDao customerDao = new CustomerDao();
		nonPocketAccounts = customerDao.getAllAccounts();
		nonPocketAccounts.removeIf(a -> ("Pocket".equals(a.getType())));
		DefaultComboBoxModel list = new DefaultComboBoxModel();
		list.addElement("");
		for(Account acct : nonPocketAccounts){
			list.addElement(Integer.toString(acct.getAcctID())+" ["+acct.getType()+"]");
		}

		linkIDComboBox = new JComboBox();
		linkIDComboBox.setModel(list);
		linkIDComboBox.setFont(new Font("Franklin Gothic Medium", Font.ITALIC, 12));
		linkIDComboBox.setBounds(82, 108, 87, 27);
		contentPane.add(linkIDComboBox);
	}

	protected void submitCreate(ActionEvent ae) {
		// TODO Auto-generated method stub
		String acctID = IDTextField.getText().toString();
		String linkID = linkIDComboBox.getSelectedItem().toString();
		linkID = linkID.replaceAll("[^0-9]", "");
		String balance = balanceTextField.getText().toString();
		String branch = branchTextField.getText().toString();
		String username = usernameTextField.getText().toString();
		String name = nameTextField.getText().toString();
		String TIN = TINTextField.getText().toString();
		String PIN = PINTextField.getText().toString();
		String address = addressTextField.getText().toString();
		String otherTIN = otherTINTextField.getText().toString();
		String type = typeComboBox.getSelectedItem().toString();
		String subtype = subtypeComboBox.getSelectedItem().toString();
		
		CustomerDao customerDao = new CustomerDao();
		allAccounts = customerDao.getAllAccounts();
		CustomerDao customerDao1 = new CustomerDao();
		allCustomers = customerDao1.getAllCustomers();
		Account newAccount = new Account();
			
		// Account ID
		if(stringUtil.isEmpty(acctID)){
			JOptionPane.showMessageDialog(this, "Please Enter New Account IDs");
			return;
		}
		for (int i = 0; i < allAccounts.size(); i++) {
			if (allAccounts.get(i).getAcctID() == Integer.valueOf(acctID)){
				JOptionPane.showMessageDialog(this, "Account ID exists");
				return;
			}
		}
		newAccount.setAcctID(Integer.valueOf(acctID));
		// Branch
		newAccount.setBranch(branch);
		// active
		newAccount.setActive(true);
		// type
		newAccount.setType(type);
		if("Checking".equals(type)){
			// creating checking account
			// Balance
			if(stringUtil.isEmpty(balance)){
				JOptionPane.showMessageDialog(this, "Please Enter Balance");
				return;
			}
			if(Double.valueOf(balance) <= 0){
				JOptionPane.showMessageDialog(this, "Please Enter a Positive Balance");
				return;
			}
			newAccount.setBalance(Double.valueOf(balance));
			
			// Subtype
			if(stringUtil.isEmpty(subtype)){
				JOptionPane.showMessageDialog(this, "Please Select a Subtype for the Checking Account You Want to Create");
				return;
			}
			newAccount.setSubType(subtype);
			if("Student".equals(subtype)){
				// Interest Rate
				newAccount.setInterestRate(0.0);
			}
			
			if("Interest".equals(subtype)){
				// Interest Rate
				newAccount.setInterestRate(0.055);
			}
			
			// Primary TIN
			if(stringUtil.isEmpty(TIN)){
				JOptionPane.showMessageDialog(this, "Please Enter the Primary Owner TIN");
				return;
			}
			Customer primaryCustomer = null;
			for (int i = 0; i < allCustomers.size(); i++) {
				if (allCustomers.get(i).getTIN().equals(TIN)){
					primaryCustomer = allCustomers.get(i);
				}
			}
			newAccount.setPrimaryTIN(TIN);
			if(primaryCustomer != null){
				AccountDao accountDao4 = new AccountDao();
				accountDao4.insertAccount(newAccount);
				AccountDao accountDao = new AccountDao();
				accountDao.insertOwnership(Integer.valueOf(acctID), TIN);
			}else{
				// create new customer
				Customer newCustomer = new Customer();
				newCustomer.setTIN(TIN);
				newCustomer.setAddress(address);
				if(stringUtil.isEmpty(username)){
					JOptionPane.showMessageDialog(this, "Please Enter Username");
					return;
				}
				for (int i = 0; i < allCustomers.size(); i++) {
					if (allCustomers.get(i).getUsername().equals(username)){
						JOptionPane.showMessageDialog(this, "This username is used!");
						return;
					}
				}
				newCustomer.setUsername(username);
				newCustomer.setName(name);
				if(!("".equals(PIN))){
					newCustomer.setPIN(PIN);
				}else{
					newCustomer.setPIN("1717");
				}
				CustomerDao customerDao2 = new CustomerDao();
				customerDao2.insertCustomer(newCustomer);
				AccountDao accountDao1 = new AccountDao();
				accountDao1.insertAccount(newAccount);
				AccountDao accountDao2 = new AccountDao();
				accountDao2.insertOwnership(Integer.valueOf(acctID), TIN);
			}
			
			// create transaction
			Transaction transac = new Transaction();
			transac.setToAcctID(newAccount.getAcctID());
			transac.setTransacType("Deposit");
			transac.setAmount(newAccount.getBalance());
			dateUtil u = new dateUtil();
			transac.setDates(u.getSysDate());
			TransactionDao transactionDao = new TransactionDao();
			transactionDao.insertTransaction(transac);
			
			// create other ownerships
			if(!stringUtil.isEmpty(balance)){
				String[] TINList = otherTIN.split(";");
				for (int i = 0; i < TINList.length; i++) {
					AccountDao accountDao3 = new AccountDao();
					accountDao3.insertOwnership(Integer.valueOf(acctID), TINList[i]);
		        }
			}
		} else if ("Savings".equals(type)){
			// creating savings account
			// Balance
			if(stringUtil.isEmpty(balance)){
				JOptionPane.showMessageDialog(this, "Please Enter Balance");
				return;
			}
			if(Double.valueOf(balance) <= 0){
				JOptionPane.showMessageDialog(this, "Please Enter a Positive Balance");
				return;
			}
			newAccount.setBalance(Double.valueOf(balance));
			
			// Interest Rate
			newAccount.setInterestRate(0.075);
			
			// Primary TIN
			if(stringUtil.isEmpty(TIN)){
				JOptionPane.showMessageDialog(this, "Please Enter the Primary Owner TIN");
				return;
			}
			Customer primaryCustomer = null;
			for (int i = 0; i < allCustomers.size(); i++) {
				if (allCustomers.get(i).getTIN().equals(TIN)){
					primaryCustomer = allCustomers.get(i);
				}
			}
			newAccount.setPrimaryTIN(TIN);
			if(primaryCustomer != null){

				AccountDao accountDao4 = new AccountDao();
				accountDao4.insertAccount(newAccount);
				AccountDao accountDao = new AccountDao();
				accountDao.insertOwnership(Integer.valueOf(acctID), TIN);
			}else{
				// create new customer
				Customer newCustomer = new Customer();
				newCustomer.setTIN(TIN);
				newCustomer.setAddress(address);
				if(stringUtil.isEmpty(username)){
					JOptionPane.showMessageDialog(this, "Please Enter Username");
					return;
				}
				for (int i = 0; i < allCustomers.size(); i++) {
					if (allCustomers.get(i).getUsername().equals(username)){
						JOptionPane.showMessageDialog(this, "This username is used!");
						return;
					}
				}
				newCustomer.setUsername(username);
				newCustomer.setName(name);
				if(!("".equals(PIN))){
					newCustomer.setPIN(PIN);
				}
				CustomerDao customerDao2 = new CustomerDao();
				customerDao2.insertCustomer(newCustomer);
				AccountDao accountDao1 = new AccountDao();
				accountDao1.insertAccount(newAccount);
				AccountDao accountDao2 = new AccountDao();
				accountDao2.insertOwnership(Integer.valueOf(acctID), TIN);
			}
			
			
			// create transaction
			Transaction transac = new Transaction();
			transac.setToAcctID(newAccount.getAcctID());
			transac.setTransacType("Deposit");
			transac.setAmount(newAccount.getBalance());
			dateUtil u = new dateUtil();
			transac.setDates(u.getSysDate());
			TransactionDao transactionDao = new TransactionDao();
			transactionDao.insertTransaction(transac);
			
			// create other ownerships
	
			if(!stringUtil.isEmpty(balance)){
				String[] TINList = otherTIN.split(";");
				for (int i = 0; i < TINList.length; i++) {
					AccountDao accountDao3 = new AccountDao();
					accountDao3.insertOwnership(Integer.valueOf(acctID), TINList[i]);
		        }
			}
			
			
		} else{
			// creating pocket account
			// Balance
			if(stringUtil.isEmpty(balance)){
				JOptionPane.showMessageDialog(this, "Please Enter Balance");
				return;
			}
			if(Double.valueOf(balance) < 0){
				JOptionPane.showMessageDialog(this, "Balance cannot be negative!");
				return;
			}
			newAccount.setBalance(Double.valueOf(balance));
			
			// Interest Rate
			newAccount.setInterestRate(0.0);
			
			// Primary TIN
			if(stringUtil.isEmpty(TIN)){
				JOptionPane.showMessageDialog(this, "Please Enter the Primary Owner TIN");
				return;
			}
			Customer primaryCustomer = null;
			for (int i = 0; i < allCustomers.size(); i++) {
				if (allCustomers.get(i).getTIN().equals(TIN)){
					primaryCustomer = allCustomers.get(i);
				}
			}
			if(primaryCustomer == null){
				JOptionPane.showMessageDialog(this, "This Customer does not exist");
				return;
			}
			
			
			// linkID
			if(stringUtil.isEmpty(linkID)){
				JOptionPane.showMessageDialog(this, "Please select account you want to link to");
				return;
			}
			// if account balance is > 0 && account belongs to TIN
			// set linkID + set PrimaryTIN + insert new account + create ownership
			// else reject
			Account linkAcct = new Account();
			for (int i = 0; i < allAccounts.size(); i++) {
				if (allAccounts.get(i).getAcctID() == Integer.valueOf(linkID)){
					linkAcct = allAccounts.get(i);
				}
			}
			
			AccountDao accountDao = new AccountDao();
			if(linkAcct.isActive() && accountDao.isOwned(linkAcct.getAcctID(), TIN)){
				newAccount.setLinkID(linkAcct.getAcctID());
				newAccount.setPrimaryTIN(TIN);
				AccountDao accountDao1 = new AccountDao();
				accountDao1.insertAccount(newAccount);
				AccountDao accountDao2 = new AccountDao();
				accountDao2.insertOwnership(Integer.valueOf(acctID), TIN);
			}else{
				JOptionPane.showMessageDialog(this, "Fail to create pocket account!");
				return;
			}
			
			
		}
		
		JOptionPane.showMessageDialog(this, "Successfully Created!");
		this.dispose();
		
		
		
	}
}
