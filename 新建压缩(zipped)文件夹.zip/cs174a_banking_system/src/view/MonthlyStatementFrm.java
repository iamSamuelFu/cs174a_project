package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Font;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

import model.Account;
import model.Customer;
import model.Transaction;
import dao.AccountDao;
import dao.AccountDao.Pair;

public class MonthlyStatementFrm extends JFrame {

	
	private JPanel contentPane;
	private JList list_1;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					MonthlyStatementFrm frame = new MonthlyStatementFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public MonthlyStatementFrm(Customer customer) {
		//System.out.print(customer.getTIN());
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1137, 884);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		JList list = new JList();
		DefaultListModel listModel;
	    listModel = new DefaultListModel();
	    listModel.addElement("Monthly Statement");
	    listModel.addElement("-----------------------------------------------------------------------------------------");
	    
	    
	    AccountDao accountDao = new AccountDao();
	    ArrayList<Account> accounts = accountDao.getStatementAccounts(customer);
	    System.out.print(accounts.size());

		for(Account acct : accounts){
			// acct info
			listModel.addElement("Account Information:");
			String account = "[Account ID: "+acct.getAcctID()+"][Type: "+acct.getType()+"]";
			listModel.addElement(account);
			listModel.addElement(" ");
			// owners: name+addres 
			AccountDao accountDao1 = new AccountDao();
			ArrayList<dao.AccountDao.Pair> ownerInfo = accountDao.nameAndAddress(acct);
			listModel.addElement("Owner Information:");
			for(Pair owner: ownerInfo){
				String str = "[Name: "+owner.getName()+"][Address: "+owner.getAddress()+"]";
				listModel.addElement(str);
			}
			// initial balance
			listModel.addElement(" ");
			AccountDao accountDao2 = new AccountDao();
			listModel.addElement("Initial Balance: " + Double.toString(accountDao2.initBalance(acct)));
			// transactions
			listModel.addElement("Transaction Information:");
			AccountDao accountDao3 = new AccountDao();
			ArrayList<Transaction> transacs = accountDao3.transactionForOneAccount(acct);
			for(Transaction t: transacs){
				DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
				String from = Integer.toString(t.getFromAcctID());
				if(t.getFromAcctID()==0){
					from = "";
				}
				String to = Integer.toString(t.getToAcctID());
				if(t.getToAcctID()==0){
					to = "";
				}
				String s = "[Transaction ID: "+Integer.toString(t.getTransacID())+"]"
						 + "[From: "+from+"]"
						 + "[To: "+to+"]"
						 + "[Type: "+t.getTransacType()+"]"
						 + "[Date: "+df.format(t.getDates())+"]"
						 + "[Amount: "+Double.toString(t.getAmount())+"]";
				listModel.addElement(s);
			}
			// final balance
			AccountDao accountDao4 = new AccountDao();
			listModel.addElement("Final Balance: " + Double.toString(acct.getBalance()));
			listModel.addElement("-----------------------------------------------------------------------------------------");
//			String str = "[Name: "+cst.getName()+"][TIN:"+cst.getTIN()+"]";
//			listModel.addElement(str);
		}
		
	    //Create the list and put it in a scroll pane.
	    list_1 = new JList(listModel);
	    list_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
	    list_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    list_1.setSelectedIndex(0);
	    list_1.setVisibleRowCount(5);
//	    JScrollPane listScrollPane = new JScrollPane(list);
		scrollPane.setViewportView(list_1);
	}

}
