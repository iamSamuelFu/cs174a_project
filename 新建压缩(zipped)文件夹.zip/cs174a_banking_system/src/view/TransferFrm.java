package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JInternalFrame;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JComboBox;

import utility.stringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

import model.Account;
import model.Customer;
import model.Transaction;
import dao.AccountDao;
import dao.CustomerDao;
import dao.TransactionDao;
import utility.dateUtil;

public class TransferFrm extends JInternalFrame {

	private JPanel contentPane;
	private JTextField transferAmountTextField;
	private JComboBox transferFromAccountComboBox;
	private JComboBox transferToAccountComboBox;
	public static Object customerObject;
	public ArrayList<Account> accounts;
	private JLabel lblToAccount;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					TransferFrm frame = new TransferFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public TransferFrm(Object customerObject) {
		this.customerObject = customerObject;
		CustomerDao customerDao = new CustomerDao();
		Customer customer = (Customer) customerObject;
		accounts = customerDao.getAccounts(customer);
		accounts.removeIf(a -> ("Pocket".equals(a.getType())));
		
		setTitle("Transfer");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 506, 345);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setClosable(true);
		setIconifiable(true);
		JLabel lbltransferAmount = new JLabel("Transfer Amount:");
		lbltransferAmount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		transferAmountTextField = new JTextField();
		transferAmountTextField.setColumns(10);
		
		JButton btnNewButton = new JButton("Transfer!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				submitTransfer(ae);
			}
		});
		btnNewButton.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JLabel lblFromAccount = new JLabel("From Account:");
		lblFromAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		DefaultComboBoxModel list1 = new DefaultComboBoxModel();
		DefaultComboBoxModel list2 = new DefaultComboBoxModel();
		for(Account acct : accounts){
			list1.addElement(Integer.toString(acct.getAcctID())+" ["+acct.getType()+"]");
			list2.addElement(Integer.toString(acct.getAcctID())+" ["+acct.getType()+"]");
		}
		transferFromAccountComboBox = new JComboBox();
		transferFromAccountComboBox.setModel(list1);
		
		lblToAccount = new JLabel("To Account:");
		lblToAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		transferToAccountComboBox = new JComboBox();
		transferToAccountComboBox.setModel(list2);
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(34)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(lbltransferAmount)
								.addComponent(lblFromAccount)
								.addComponent(lblToAccount))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(transferToAccountComboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(transferFromAccountComboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(transferAmountTextField, GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(175)
							.addComponent(btnNewButton)))
					.addContainerGap(70, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(44)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lbltransferAmount)
						.addComponent(transferAmountTextField, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
					.addGap(33)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblFromAccount)
						.addComponent(transferFromAccountComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblToAccount)
						.addComponent(transferToAccountComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
					.addComponent(btnNewButton)
					.addGap(36))
		);
		contentPane.setLayout(gl_contentPane);
	}

	protected void submitTransfer(ActionEvent ae) {
		// TODO Auto-generated method stub
		String transferAmount = transferAmountTextField.getText().toString();
		String selectedAcctFrom = transferFromAccountComboBox.getSelectedItem().toString();
		String selectedAcctTo = transferToAccountComboBox.getSelectedItem().toString();
		
		//String numberOnly= selectedAcct.replaceAll("[^0-9]", "");
		if(stringUtil.isEmpty(transferAmount)){
			JOptionPane.showMessageDialog(this, "Please Enter the Amount You Want To Transfer");
			return;
		}
		
		if(selectedAcctFrom.equals(selectedAcctTo)){
			JOptionPane.showMessageDialog(this, "Please Select A Different Account To Transfer");
			return;
		}
		
		int acctIDFrom = Integer.parseInt(selectedAcctFrom.replaceAll("[^0-9]", ""));
		int acctIDTo = Integer.parseInt(selectedAcctTo.replaceAll("[^0-9]", ""));
		AccountDao accountDao = new AccountDao();
		//accounts.removeIf(a -> (acctID == a.getAcctID()));
		Account accountFrom = new Account();
		Account accountTo = new Account();
		for (int i = 0; i < accounts.size(); i++){
			if (accounts.get(i).getAcctID() == acctIDFrom){
			   accountFrom = accounts.get(i);
			}
			if (accounts.get(i).getAcctID() == acctIDTo){
				   accountTo = accounts.get(i);
			}
		}
		if(2000 < Double.valueOf(transferAmount)){
			JOptionPane.showMessageDialog(this, "You have reached maximum of $2,000. Please try again.");
			return;
		}
		if(accountFrom.getBalance() < Double.valueOf(transferAmount)){
			JOptionPane.showMessageDialog(this, "Insufficient Fund");
			return;
		}
		if(!accountDao.transfer(accountFrom, accountTo, Double.valueOf(transferAmount))){
			JOptionPane.showMessageDialog(this, "Transfer Fail");
		}else{
			JOptionPane.showMessageDialog(this, "Transfer Successful");
			if((accountFrom.getBalance()-Double.valueOf(transferAmount)) <= 0.01){
				AccountDao closeDao = new AccountDao();
				if(closeDao.closeAccount(accountFrom)){
					JOptionPane.showMessageDialog(this, "Account is closed!");
				}
			}
		}
		
		Transaction transac = new Transaction();
		transac.setFromAcctID(acctIDFrom);
		transac.setToAcctID(acctIDTo);
		transac.setTransacType("Transfer");
		transac.setAmount(Double.valueOf(transferAmount));
		dateUtil u = new dateUtil();
		transac.setDates(u.getSysDate());
		TransactionDao transactionDao = new TransactionDao();
		transactionDao.insertTransaction(transac);
		
		this.dispose();
		
	}
}

