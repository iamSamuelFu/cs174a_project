package view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;

import model.Customer;
import dao.AccountDao;
import utility.stringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class setPINFrm extends JInternalFrame {
	private JTextField oldPINTextField;
	private JTextField newPINTextField;
	public static Object customerObject;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					setPINFrm frame = new setPINFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public setPINFrm(Object customerObject) {
		this.customerObject = customerObject;
		setTitle("Reset Password");
		setBounds(100, 100, 447, 341);
		setClosable(true);
		setIconifiable(true);
		JLabel lblNewLabel = new JLabel("Old PIN:");
		lblNewLabel.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		oldPINTextField = new JTextField();
		oldPINTextField.setColumns(10);
		
		JLabel lblNewPassword = new JLabel("New PIN:");
		lblNewPassword.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		newPINTextField = new JTextField();
		newPINTextField.setColumns(10);
		
		JButton btnSet = new JButton("Confirm");
		btnSet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				submitNewPIN(ae);
			}
		});
		btnSet.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap(170, Short.MAX_VALUE)
					.addComponent(btnSet)
					.addGap(160))
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(34)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel)
						.addComponent(lblNewPassword))
					.addGap(20)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(oldPINTextField, GroupLayout.PREFERRED_SIZE, 238, GroupLayout.PREFERRED_SIZE)
						.addComponent(newPINTextField, GroupLayout.PREFERRED_SIZE, 238, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(62, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(77)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(oldPINTextField, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
					.addGap(26)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewPassword)
						.addComponent(newPINTextField, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE))
					.addGap(61)
					.addComponent(btnSet)
					.addContainerGap(58, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);

	}

	protected void submitNewPIN(ActionEvent ae) {
		// TODO Auto-generated method stub
		String oldPIN = oldPINTextField.getText().toString();
		String newPIN = newPINTextField.getText().toString();
		Customer customer = (Customer)customerObject;
		if(stringUtil.isEmpty(oldPIN)){
			JOptionPane.showMessageDialog(this, "Please enter the old PIN number!");
			return;
		}
		if(stringUtil.isEmpty(newPIN)){
			JOptionPane.showMessageDialog(this, "Please enter a new PIN number!");
			return;
		}
		if(newPIN.length()!= 4){
			JOptionPane.showMessageDialog(this, "PIN must be 4-digit!");
			return;
		}
		if(oldPIN.equals(newPIN)){
			JOptionPane.showMessageDialog(this, "Please use a different PIN number!");
			return;
		}
		if(!oldPIN.equals(customer.getPIN())){
			JOptionPane.showMessageDialog(this, "Please enter correct old PIN number!");
			return;
		}
		AccountDao accountDao = new AccountDao();
		if(!accountDao.setPIN(customer, oldPIN, newPIN)){
			JOptionPane.showMessageDialog(this, "Fail!");
		}else{
			JOptionPane.showMessageDialog(this, "Success! Please log in again!");
			System.exit(0);
		}
		this.dispose();
	}

}
