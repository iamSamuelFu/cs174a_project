package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import java.awt.Font;
import java.awt.Color;

import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

import dao.CustomerDao;
import utility.stringUtil;
import model.Customer;
import model.UserType;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginFrm extends JFrame {

	private JPanel contentPane;
	private JTextField usernameTextField;
	private JTextField passwordTextField;
	private JComboBox userTypeComboBox;
	private JLabel lblPassword;
	private JLabel lblUserType;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrm frame = new LoginFrm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrm() {
		setTitle("Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 646, 519);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
		usernameTextField = new JTextField();
		usernameTextField.setColumns(10);
		
		passwordTextField = new JTextField();
		passwordTextField.setColumns(10);
		
		userTypeComboBox = new JComboBox();
		userTypeComboBox.setForeground(Color.BLACK);
		userTypeComboBox.setBackground(Color.LIGHT_GRAY);
		userTypeComboBox.setModel(new DefaultComboBoxModel(new UserType[] {UserType.Customer, UserType.BankTeller}));
		userTypeComboBox.setFont(new Font("Franklin Gothic Medium", Font.ITALIC, 22));
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				loginAct(ae);
			}
		});
		btnLogin.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 25));
		
		JLabel lblNewLabel = new JLabel("DebtsRus State Bank Login");
		lblNewLabel.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 42));
		
		JLabel lblUsername = new JLabel("Username");
		lblUsername.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 25));
		
		lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 25));
		
		lblUserType = new JLabel("User Type");
		lblUserType.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 25));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(120)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblUsername)
								.addComponent(lblPassword)
								.addComponent(lblUserType))
							.addGap(27)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(usernameTextField, GroupLayout.PREFERRED_SIZE, 273, GroupLayout.PREFERRED_SIZE)
								.addComponent(userTypeComboBox, GroupLayout.PREFERRED_SIZE, 165, GroupLayout.PREFERRED_SIZE)
								.addComponent(passwordTextField, 273, 273, 273)
								.addComponent(btnLogin, GroupLayout.PREFERRED_SIZE, 109, GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(61)
							.addComponent(lblNewLabel)))
					.addContainerGap(60, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(62)
					.addComponent(lblNewLabel)
					.addGap(46)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblUsername)
						.addComponent(usernameTextField, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE))
					.addGap(22)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblPassword)
						.addComponent(passwordTextField, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE))
					.addGap(48)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addComponent(userTypeComboBox, 0, 0, Short.MAX_VALUE)
						.addComponent(lblUserType, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(60)
					.addComponent(btnLogin, GroupLayout.PREFERRED_SIZE, 56, GroupLayout.PREFERRED_SIZE)
					.addGap(29))
		);
		contentPane.setLayout(gl_contentPane);
	}

	protected void loginAct(ActionEvent ae) {
		String username = usernameTextField.getText().toString();
		String password = passwordTextField.getText().toString();
		UserType selectedItem = (UserType)userTypeComboBox.getSelectedItem();
//		if(stringUtil.isEmpty(username)){
//			JOptionPane.showMessageDialog(this, "Username can not be empty!");
//			return;
//		}
//		if(stringUtil.isEmpty(password)){
//			JOptionPane.showMessageDialog(this, "Password can not be empty!");
//			return;
//		}
		Customer customer = null;
		if("Customer".equals(selectedItem.getName())){
			if(stringUtil.isEmpty(username)){
				JOptionPane.showMessageDialog(this, "Username can not be empty!");
				return;
			}
			if(stringUtil.isEmpty(password)){
				JOptionPane.showMessageDialog(this, "Password can not be empty!");
				return;
			}
			CustomerDao customerDao = new CustomerDao();
			Customer customerTmp = new Customer();
			customerTmp.setUsername(username);
			customerTmp.setPIN(password);
			customer = customerDao.verifyPIN(customerTmp);
			if(customer == null){
				JOptionPane.showMessageDialog(this, "Username or PIN is incorrect!");
				return;
			}
			JOptionPane.showMessageDialog(this,"Welcome back! "+customer.getName()+"!");
			this.dispose();
			new CustomerMainFrm(customer).setVisible(true);
			//customer login
		}else{
			//bank teller login
			new BankTellerFrm().setVisible(true);
		}
	}
}
