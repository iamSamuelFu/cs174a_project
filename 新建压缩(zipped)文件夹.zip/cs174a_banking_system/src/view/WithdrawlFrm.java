package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JInternalFrame;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JComboBox;

import utility.stringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

import model.Account;
import model.Customer;
import model.Transaction;
import dao.AccountDao;
import dao.CustomerDao;
import dao.TransactionDao;
import utility.dateUtil;

public class WithdrawlFrm extends JInternalFrame {

	private JPanel contentPane;
	private JTextField withdrawlAmountTextField;
	private JComboBox withdrawlAccountComboBox;
	public static Object customerObject;
	public ArrayList<Account> accounts;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					WithdrawlFrm frame = new WithdrawlFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public WithdrawlFrm(Object customerObject) {
		this.customerObject = customerObject;
		CustomerDao customerDao = new CustomerDao();
		Customer customer = (Customer) customerObject;
		accounts = customerDao.getAccounts(customer);
		accounts.removeIf(a -> ("Pocket".equals(a.getType())));
		
		setTitle("Withdrawl");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 506, 345);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setClosable(true);
		setIconifiable(true);
		JLabel lblwithdrawlAmount = new JLabel("Withdrawl Amount:");
		lblwithdrawlAmount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		withdrawlAmountTextField = new JTextField();
		withdrawlAmountTextField.setColumns(10);
		
		JButton btnNewButton = new JButton("Withdrawl!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				submitWithdrawl(ae);
			}
		});
		btnNewButton.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JLabel lblAccount = new JLabel("Account:");
		lblAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		DefaultComboBoxModel list = new DefaultComboBoxModel();
		for(Account acct : accounts){
			list.addElement(Integer.toString(acct.getAcctID())+" ["+acct.getType()+"]");
		}
		withdrawlAccountComboBox = new JComboBox();
		withdrawlAccountComboBox.setModel(list);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(34)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(lblAccount)
								.addComponent(lblwithdrawlAmount))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(withdrawlAccountComboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(withdrawlAmountTextField, GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(173)
							.addComponent(btnNewButton)))
					.addContainerGap(75, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(44)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblwithdrawlAmount)
						.addComponent(withdrawlAmountTextField, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
					.addGap(33)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAccount)
						.addComponent(withdrawlAccountComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(63)
					.addComponent(btnNewButton)
					.addContainerGap(77, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

	protected void submitWithdrawl(ActionEvent ae) {
		// TODO Auto-generated method stub
		String withdrawlAmount = withdrawlAmountTextField.getText().toString();
		String selectedAcct = withdrawlAccountComboBox.getSelectedItem().toString();
		
		//String numberOnly= selectedAcct.replaceAll("[^0-9]", "");
		if(stringUtil.isEmpty(withdrawlAmount)){
			JOptionPane.showMessageDialog(this, "Please Enter the Amount You Want To Withdrawl");
			return;
		}
		int acctID = Integer.parseInt(selectedAcct.replaceAll("[^0-9]", ""));
		AccountDao accountDao = new AccountDao();
		//accounts.removeIf(a -> (acctID == a.getAcctID()));
		Account accountTmp = new Account();
		for (int i = 0; i < accounts.size(); i++) {
			if (accounts.get(i).getAcctID() == acctID){
			   accountTmp = accounts.get(i);
			}
		}
		
		if(accountTmp.getBalance() < Double.valueOf(withdrawlAmount)){
			JOptionPane.showMessageDialog(this, "Insufficient Fund");
			return;
		}
		
		if(!accountDao.withdrawl(accountTmp, Double.valueOf(withdrawlAmount))){
			JOptionPane.showMessageDialog(this, "Withdrawl Fail");
		}else{
			JOptionPane.showMessageDialog(this, "Withdrawl Successful");
			if((accountTmp.getBalance()-Double.valueOf(withdrawlAmount)) <= 0.01){
				AccountDao closeDao = new AccountDao();
				if(closeDao.closeAccount(accountTmp)){
					JOptionPane.showMessageDialog(this, "Account is closed!");
				}
			}
		}
		
		Transaction transac = new Transaction();
		transac.setFromAcctID(acctID);
//		transac.setToAcctID(acctID);
		transac.setTransacType("Withdrawl");
		transac.setAmount(Double.valueOf(withdrawlAmount));
		dateUtil u = new dateUtil();
		transac.setDates(u.getSysDate());
		TransactionDao transactionDao = new TransactionDao();
		transactionDao.insertTransaction(transac);
		
		this.dispose();
		
	}
}
