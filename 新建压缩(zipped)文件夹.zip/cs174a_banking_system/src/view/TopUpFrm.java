package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JInternalFrame;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JComboBox;

import utility.stringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

import model.Account;
import model.Customer;
import model.Transaction;
import dao.AccountDao;
import dao.CustomerDao;
import dao.TransactionDao;
import utility.dateUtil;

public class TopUpFrm extends JInternalFrame {

	private JPanel contentPane;
	private JTextField topUpAmountTextField;
	private JComboBox topUpAccountComboBox;
	public static Object customerObject;
	public ArrayList<Account> accounts;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					TopUpFrm frame = new TopUpFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public TopUpFrm(Object customerObject) {
		this.customerObject = customerObject;
		CustomerDao customerDao = new CustomerDao();
		Customer customer = (Customer) customerObject;
		accounts = customerDao.getAccounts(customer);
		accounts.removeIf(a -> !("Pocket".equals(a.getType())));
		
		setTitle("TopUp");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 506, 345);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setClosable(true);
		setIconifiable(true);
		JLabel lblTopUpAmount = new JLabel("Top-Up Amount:");
		lblTopUpAmount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		topUpAmountTextField = new JTextField();
		topUpAmountTextField.setColumns(10);
		
		JButton btnNewButton = new JButton("Top-Up!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				submitTopUp(ae);
			}
		});
		btnNewButton.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JLabel lblAccount = new JLabel("Pocket Account:");
		lblAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		DefaultComboBoxModel list = new DefaultComboBoxModel();
		for(Account acct : accounts){
			list.addElement(Integer.toString(acct.getAcctID())+" ["+acct.getType()+"]");
		}
		topUpAccountComboBox = new JComboBox();
		topUpAccountComboBox.setModel(list);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(34)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblAccount)
						.addComponent(lblTopUpAmount))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnNewButton)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
							.addComponent(topUpAccountComboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(topUpAmountTextField, GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE)))
					.addContainerGap(80, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(44)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblTopUpAmount)
						.addComponent(topUpAmountTextField, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
					.addGap(33)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblAccount)
						.addComponent(topUpAccountComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(63)
					.addComponent(btnNewButton)
					.addContainerGap(77, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

	protected void submitTopUp(ActionEvent ae) {
		// TODO Auto-generated method stub
		String topUpAmount = topUpAmountTextField.getText().toString();
		String selectedAcct = topUpAccountComboBox.getSelectedItem().toString();
		
		//String numberOnly= selectedAcct.replaceAll("[^0-9]", "");
		if(stringUtil.isEmpty(topUpAmount)){
			JOptionPane.showMessageDialog(this, "Please Enter the Amount You Want To TopUp");
			return;
		}
		int acctID = Integer.parseInt(selectedAcct.replaceAll("[^0-9]", ""));
		AccountDao accountDao = new AccountDao();
		//accounts.removeIf(a -> (acctID == a.getAcctID()));
		Account accountTmp = new Account();
		for (int i = 0; i < accounts.size(); i++) {
			if (accounts.get(i).getAcctID() == acctID){
			   accountTmp = accounts.get(i);
			}
		}
		
		double linkedAcctBalance = accountDao.topUp(accountTmp, Double.valueOf(topUpAmount));
		
		
		
		if(linkedAcctBalance == -2){
			JOptionPane.showMessageDialog(this, "Insufficient Fund");
			return;
		}
		
		if(linkedAcctBalance == -1){
			JOptionPane.showMessageDialog(this, "TopUp Fail");
		}else{
			JOptionPane.showMessageDialog(this, "TopUp Successful");
		}
		
		AccountDao checkMonthlyFee = new AccountDao();
		if(!checkMonthlyFee.alreadyAddedFee(accountTmp)){
			Transaction transac = new Transaction();
			transac.setFromAcctID(accountTmp.getAcctID());
			transac.setTransacType("Monthly Fee");
			transac.setAmount(5.0);
			dateUtil u = new dateUtil();
			transac.setDates(u.getSysDate());
			TransactionDao transactionDao1 = new TransactionDao();
			transactionDao1.insertTransaction(transac);
		}
		
		Transaction transac = new Transaction();
		transac.setFromAcctID(accountTmp.getLinkID());
		transac.setToAcctID(acctID);
		transac.setTransacType("Top-Up");
		transac.setAmount(Double.valueOf(topUpAmount));
		dateUtil u = new dateUtil();
		transac.setDates(u.getSysDate());
		TransactionDao transactionDao = new TransactionDao();
		transactionDao.insertTransaction(transac);
		
		this.dispose();
		
	}
}
