package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JInternalFrame;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JComboBox;

import utility.stringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

import model.Account;
import model.Customer;
import model.Transaction;
import dao.AccountDao;
import dao.CustomerDao;
import dao.TransactionDao;
import utility.dateUtil;

public class CheckTransactionFrm extends JFrame {

	private JPanel contentPane;
	private JTextField checkTransactionAmountTextField;
	private JComboBox checkTransactionFromAccountComboBox;
	public ArrayList<Account> accounts;
	private JLabel lblToAccount;
	private JTextField toAccountTextField;
	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					CheckTransactionFrm frame = new CheckTransactionFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public CheckTransactionFrm() {
		CustomerDao customerDao = new CustomerDao();
		accounts = customerDao.getAllAccounts();
		accounts.removeIf(a -> !("Checking".equals(a.getType())));
		
		setTitle("CheckTransaction");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 506, 345);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
//		setClosable(true);
//		setIconifiable(true);
		JLabel lblcheckTransactionAmount = new JLabel("Transaction Amount:");
		lblcheckTransactionAmount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		checkTransactionAmountTextField = new JTextField();
		checkTransactionAmountTextField.setColumns(10);
		
		JButton btnNewButton = new JButton("Check Transaction!");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				submitCheckTransaction(ae);
			}
		});
		btnNewButton.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		JLabel lblFromAccount = new JLabel("Account:");
		lblFromAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		DefaultComboBoxModel list1 = new DefaultComboBoxModel();
		DefaultComboBoxModel list2 = new DefaultComboBoxModel();
		for(Account acct : accounts){
			list1.addElement(Integer.toString(acct.getAcctID())+" ["+acct.getType()+"]");
			list2.addElement(Integer.toString(acct.getAcctID())+" ["+acct.getType()+"]");
		}
		checkTransactionFromAccountComboBox = new JComboBox();
		checkTransactionFromAccountComboBox.setModel(list1);
		
		lblToAccount = new JLabel("Check #:");
		lblToAccount.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		toAccountTextField = new JTextField();
		toAccountTextField.setColumns(10);
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(34)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(lblcheckTransactionAmount)
								.addComponent(lblFromAccount)
								.addComponent(lblToAccount))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(checkTransactionFromAccountComboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(checkTransactionAmountTextField, GroupLayout.DEFAULT_SIZE, 223, Short.MAX_VALUE)
								.addComponent(toAccountTextField)))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(175)
							.addComponent(btnNewButton)))
					.addContainerGap(94, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(44)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblcheckTransactionAmount)
						.addComponent(checkTransactionAmountTextField, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE))
					.addGap(33)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblFromAccount)
						.addComponent(checkTransactionFromAccountComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblToAccount)
						.addComponent(toAccountTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
					.addComponent(btnNewButton)
					.addGap(36))
		);
		contentPane.setLayout(gl_contentPane);
	}

	protected void submitCheckTransaction(ActionEvent ae) {
		// TODO Auto-generated method stub
		String checkTransactionAmount = checkTransactionAmountTextField.getText().toString();
		String selectedAcctTo = checkTransactionFromAccountComboBox.getSelectedItem().toString();   //checking account
		String checkNumber = toAccountTextField.getText().toString();  //check number
		
		//String numberOnly= selectedAcct.replaceAll("[^0-9]", "");
		if(stringUtil.isEmpty(checkTransactionAmount)){
			JOptionPane.showMessageDialog(this, "Please Enter the Amount On the Check");
			return;
		}
		if(stringUtil.isEmpty(checkNumber)){
			JOptionPane.showMessageDialog(this, "Please Enter the Check Number");
			return;
		}
		
		int acctIDTo = Integer.parseInt(selectedAcctTo.replaceAll("[^0-9]", ""));
		int checkNumberInt = Integer.parseInt(checkNumber.replaceAll("[^0-9]", ""));
		
		
		AccountDao accountDao = new AccountDao();
		//accounts.removeIf(a -> (acctID == a.getAcctID()));

		Account accountTo = null;
		for (int i = 0; i < accounts.size(); i++){
			if (accounts.get(i).getAcctID() == acctIDTo){
			   accountTo = accounts.get(i);
			}
		}
		
		if(accountTo == null){
			JOptionPane.showMessageDialog(this, "Invalid Account");
			return;
		}
		
		if(accountTo.getBalance() < Double.valueOf(checkTransactionAmount)){
			JOptionPane.showMessageDialog(this, "Insufficient Fund");
			return;
		}
		
		if(!accountDao.checkTransaction(accountTo, Double.valueOf(checkTransactionAmount))){
			JOptionPane.showMessageDialog(this, "Check Transaction Fail");
		}else{
			JOptionPane.showMessageDialog(this, "Check Transaction Successful");
			if((accountTo.getBalance()- Double.valueOf(checkTransactionAmount)) <= 0.01){
				AccountDao closeDao = new AccountDao();
				if(closeDao.closeAccount(accountTo)){
					JOptionPane.showMessageDialog(this, "Account is closed!");
				}
			}
		}
		
		Transaction transac = new Transaction();

		transac.setFromAcctID(acctIDTo);   
//		transac.setToAcctID(acctIDTo);
		transac.setTransacType("Write-Check");
		transac.setAmount(Double.valueOf(checkTransactionAmount));
		transac.setCheckNum(checkNumberInt);
		dateUtil u = new dateUtil();
		transac.setDates(u.getSysDate());
		
		TransactionDao transactionDao = new TransactionDao();
		transactionDao.insertTransaction(transac);
		
		this.dispose();
		
	}
}

