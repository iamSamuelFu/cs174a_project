package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;

import utility.dateUtil;
import utility.stringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.Date;

public class SetDateFrm extends JFrame {

	private JPanel contentPane;
	private JTextField yearTextField;
	private JTextField monthTextField;
	private JTextField dayTextField;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					SetDateFrm frame = new SetDateFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public SetDateFrm() {
		setTitle("Set New Date");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 355, 302);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
		JLabel lblYear = new JLabel("Please Enter The Date (yyyy-MM-dd):");
		lblYear.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		
		yearTextField = new JTextField();
		yearTextField.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		yearTextField.setColumns(10);
		
		JLabel label = new JLabel("-");
		label.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		monthTextField = new JTextField();
		monthTextField.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		monthTextField.setColumns(10);
		
		JLabel label_1 = new JLabel("-");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		dayTextField = new JTextField();
		dayTextField.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		dayTextField.setColumns(10);
		
		JButton btnSet = new JButton("Set!");
		btnSet.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				setNewDate(ae);
			}
		});
		btnSet.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 18));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addComponent(yearTextField, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(btnSet)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(label)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(monthTextField, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 7, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(dayTextField, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(46, Short.MAX_VALUE))
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(lblYear)
					.addContainerGap())
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(55)
					.addComponent(lblYear)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
							.addComponent(monthTextField)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(yearTextField)
								.addComponent(label)))
						.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
							.addComponent(label_1, GroupLayout.PREFERRED_SIZE, 22, GroupLayout.PREFERRED_SIZE)
							.addComponent(dayTextField, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE)))
					.addGap(35)
					.addComponent(btnSet)
					.addGap(56))
		);
		contentPane.setLayout(gl_contentPane);
	}

	protected void setNewDate(ActionEvent ae) {
		// TODO Auto-generated method stub
		String year = yearTextField.getText().toString();
		String month = monthTextField.getText().toString();
		String day = dayTextField.getText().toString();
		if(stringUtil.isEmpty(year) || stringUtil.isEmpty(month) || stringUtil.isEmpty(day)){
			JOptionPane.showMessageDialog(this, "Please Enter the Date You Want To Change To");
			return;
		}
		dateUtil du = new dateUtil();
		du.setSysDate(Date.valueOf(year+"-"+month+"-"+day));
		JOptionPane.showMessageDialog(this, "Success!");
		this.dispose();
		
	}

}
