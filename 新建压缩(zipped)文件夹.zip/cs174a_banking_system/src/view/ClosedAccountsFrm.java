package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.DefaultListModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.ListSelectionModel;

import model.Account;
import model.Customer;
import dao.CustomerDao;

import java.awt.Font;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class ClosedAccountsFrm extends JFrame {

	private JPanel contentPane;
	private JList list_1;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					ClosedAccountsFrm frame = new ClosedAccountsFrm();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public ClosedAccountsFrm() {
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 729, 496);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane = new JScrollPane();
		contentPane.add(scrollPane, BorderLayout.CENTER);
		
		JList list = new JList();
		DefaultListModel listModel;
	    listModel = new DefaultListModel();
	    listModel.addElement("List of Closed Accounts:");
	    listModel.addElement("-----------------------------------------------------------------------------------------");
	    CustomerDao customerDao = new CustomerDao();
		ArrayList<Account> accounts = customerDao.getAllClosedAccounts();
		for(Account acct : accounts){
			String str = "[Account Number: "+Integer.toString(acct.getAcctID())+"]["+acct.getType()+"][Status: Closed]";
			listModel.addElement(str);
		}
		
	    //Create the list and put it in a scroll pane.
	    list_1 = new JList(listModel);
	    list_1.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
	    list_1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
	    list_1.setSelectedIndex(0);
	    list_1.setVisibleRowCount(5);
//	    JScrollPane listScrollPane = new JScrollPane(list);
		scrollPane.setViewportView(list_1);
	}

}
