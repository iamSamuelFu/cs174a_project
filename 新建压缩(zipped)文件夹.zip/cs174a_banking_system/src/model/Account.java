package model;

import java.sql.Date;

public class Account {
	private int acctID;
	private double balance;
	private String branch;
	private String primaryTIN;
	private String type;
	private String subType;
	private boolean active;
	private double interestRate;
	private int linkID = -1;
	private Date closedDates;
	
//	public Account(int acctID, double balance, String branch, String primaryTIN,
//			String type, String subType, boolean active, double interestRate,
//			int linkID) {
//		super();
//		this.acctID = acctID;
//		this.balance = balance;
//		this.branch = branch;
//		this.primaryTIN = primaryTIN;
//		this.type = type;
//		this.subType = subType;
//		this.active = active;
//		this.interestRate = interestRate;
//		this.linkID = linkID;
//	}

	public Date getClosedDates() {
		return closedDates;
	}

	public void setClosedDates(Date closedDates) {
		this.closedDates = closedDates;
	}

	public int getAcctID() {
		return acctID;
	}

	public void setAcctID(int acctID) {
		this.acctID = acctID;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getPrimaryTIN() {
		return primaryTIN;
	}

	public void setPrimaryTIN(String primaryTIN) {
		this.primaryTIN = primaryTIN;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSubType() {
		return subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public int getLinkID() {
		return linkID;
	}

	public void setLinkID(int linkID) {
		this.linkID = linkID;
	}
	
	
	

}
