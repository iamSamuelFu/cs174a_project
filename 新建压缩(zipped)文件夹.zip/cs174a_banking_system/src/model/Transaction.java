package model;

import java.sql.Date;

public class Transaction {
	private int transacID;
	private int fromAcctID = -1;
	private int toAcctID = -1;
	private String transacType;
	private Date dates;
	private double amount;
	private int checkNum = -1;
	public int getTransacID() {
		return transacID;
	}
	public void setTransacID(int transacID) {
		this.transacID = transacID;
	}
	public int getFromAcctID() {
		return fromAcctID;
	}
	public void setFromAcctID(int fromAcctID) {
		this.fromAcctID = fromAcctID;
	}
	public int getToAcctID() {
		return toAcctID;
	}
	public void setToAcctID(int toAcctID) {
		this.toAcctID = toAcctID;
	}
	public String getTransacType() {
		return transacType;
	}
	public void setTransacType(String transacType) {
		this.transacType = transacType;
	}
	public Date getDates() {
		return dates;
	}
	public void setDates(Date dates) {
		this.dates = dates;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public int getCheckNum() {
		return checkNum;
	}
	public void setCheckNum(int checkNum) {
		this.checkNum = checkNum;
	}
	
}
