package utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbUtil {
	private String dbUrl ="jdbc:oracle:thin:@cloud-34-133.eci.ucsb.edu:1521:XE";
	private String dbUsername="xingxinggeng"; // username
	private String dbPassword="gengstar"; // password
	private String jdbcName="oracle.jdbc.driver.OracleDriver"; // name of driver
	/**
	 * ��ȡ���ݿ�����	
	 * @return
	 * @throws Exception
	 */
	public Connection getCon(){
		try{
			Class.forName(jdbcName);
		} catch (ClassNotFoundException e){
			e.printStackTrace();
		}
		Connection con = null;
		try{
			con = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
		} catch (SQLException e){
			e.printStackTrace();
		}
		return con;
	}
	
	/**
	 * �ر����ݿ�����
	 * @param con
	 * @throws Exception
	 */
	public void closeCon(Connection con)throws Exception{
		if(con!=null){
			con.close();
		}
	}
	
	public static void main(String[] args){
		dbUtil dbu = new dbUtil();
		try{
			dbu.getCon();
			System.out.println("Successfully connected!");
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Failed connection");
		}
	}

}
