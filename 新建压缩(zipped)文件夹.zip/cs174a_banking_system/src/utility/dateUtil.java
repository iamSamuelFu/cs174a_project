package utility;

import java.sql.Date;
import java.util.Calendar;

public class dateUtil {
	public static Date sysDate = new Date(Calendar.getInstance().getTime().getTime());

	public static Date getSysDate() {
		return sysDate;
	}

	public static void setSysDate(Date sysDate) {
		dateUtil.sysDate = sysDate;
	}
	
}
